import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { LayoutDashboard, Video, Search, Bell, Network, X, PanelLeftClose, PanelLeftOpen, LogOut } from "lucide-react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import InvestigationDrawer, { CameraPanel } from "./components/InvestigationDrawer";
import Dashboard from "./pages/Dashboard";
import { LiveCameras, ANPRPage, NetworkPage } from "./pages/Operations";
import { SearchPage, TrajectoryPage, AnalyticsPage, AlertsPage, ReportsPage, SettingsPage } from "./pages/Intel";
import { Logo } from "./components/Sidebar";
import Login from "./pages/Login";
import { getRole, type RoleConfig } from "./data/roles";
import type { Camera as CamType } from "./data/mock";
import { cn } from "./utils/cn";

const MOBILE_NAV = [
  { id: "dashboard", icon: LayoutDashboard, label: "Home" },
  { id: "cameras", icon: Video, label: "Feeds" },
  { id: "search", icon: Search, label: "Search" },
  { id: "alerts", icon: Bell, label: "Alerts" },
  { id: "network", icon: Network, label: "Grid" },
];

const TICKER = [
  "GJ-05-XY-9999 · BLACKLIST MATCH · Race Course",
  "City flow 12,482 veh/h · +8.2%",
  "CAM-WR-021 degraded · 12 FPS",
  "GJ-06-CD-5678 · impossible travel · 91% conf",
  "Congestion 18% · Manjalpur corridor heavy",
  "218 / 220 cameras online",
];

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [plate, setPlate] = useState<string | null>(null);
  const [camera, setCamera] = useState<CamType | null>(null);
  const [query, setQuery] = useState("");
  const [searchPlate, setSearchPlate] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [booted, setBooted] = useState(false);
  const [user, setUser] = useState<RoleConfig | null>(() => {
    try { return getRole(localStorage.getItem("gs_role")); } catch { return null; }
  });

  // boot splash plays each time a session starts
  useEffect(() => {
    if (!user) return;
    setBooted(false);
    const t = setTimeout(() => setBooted(true), 1300);
    return () => clearTimeout(t);
  }, [user?.key]);

  const login = (r: RoleConfig) => {
    try { localStorage.setItem("gs_role", r.key); } catch { /* ignore */ }
    setPage("dashboard");
    setUser(r);
  };
  const logout = () => {
    try { localStorage.removeItem("gs_role"); } catch { /* ignore */ }
    setPlate(null); setCamera(null); setMobileMenu(false);
    setUser(null);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") { e.preventDefault(); document.querySelector<HTMLInputElement>("header input")?.focus(); }
      if (e.key === "Escape") { setPlate(null); setCamera(null); setMobileMenu(false); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const nav = (id: string) => { setPage(id); setMobileMenu(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const investigate = (p: string) => { setCamera(null); setPlate(p); };
  const searchFromHeader = (p: string) => { setSearchPlate(p); setPage("search"); setQuery(""); };

  if (!user) return <Login onLogin={login} />;

  return (
    <div className="min-h-screen bg-[#050507] text-white">
      {/* boot splash */}
      <AnimatePresence>
        {!booted && (
          <motion.div exit={{ opacity: 0 }} transition={{ duration: 0.4 }} className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#050507]">
            <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.5 }}>
              <Logo />
            </motion.div>
            <div className="mt-6 font-mono text-[11px] font-bold tracking-[.3em] text-white/40">INITIALIZING COMMAND CENTER</div>
            <div className="mt-4 h-1 w-56 overflow-hidden rounded-full bg-white/10">
              <motion.div initial={{ width: "4%" }} animate={{ width: "100%" }} transition={{ duration: 1.2, ease: "easeInOut" }} className="h-full rounded-full bg-[#b8ff2e] shadow-[0_0_12px_#b8ff2e]" />
            </div>
            <div className="mt-3 flex gap-4 font-mono text-[10px] text-white/30">
              <span>ANPR ●</span><span>GRID ●</span><span>AI CORE ●</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mx-auto flex max-w-[1760px]">
        <Sidebar active={page} onNav={nav} collapsed={collapsed} user={user} onLogout={logout} />

        <div className="min-w-0 flex-1">
          <Header onMenu={() => setMobileMenu(true)} onSearchPlate={searchFromHeader} query={query} setQuery={setQuery} user={user} onLogout={logout} />

          {/* intel ticker */}
          <div className="relative overflow-hidden border-b border-white/[.06] bg-[#07070c]">
            <div className="flex w-max items-center gap-8 py-1.5 pl-4" style={{ animation: "marquee-x 36s linear infinite" }}>
              {[...TICKER, ...TICKER].map((t, i) => (
                <span key={i} className="flex items-center gap-2 whitespace-nowrap font-mono text-[10.5px] font-bold tracking-wide text-white/40">
                  <span className={cn("h-1.5 w-1.5 rounded-full", i % 3 === 0 ? "bg-[#ff3b4e]" : i % 3 === 1 ? "bg-[#b8ff2e]" : "bg-[#ffc93c]")} />
                  {t}
                </span>
              ))}
            </div>
            <button onClick={() => setCollapsed(!collapsed)} className="absolute right-3 top-1/2 hidden -translate-y-1/2 rounded-lg border border-white/10 bg-[#0b0b10] p-1.5 text-white/40 transition hover:text-white lg:block">
              {collapsed ? <PanelLeftOpen className="h-3.5 w-3.5" /> : <PanelLeftClose className="h-3.5 w-3.5" />}
            </button>
          </div>

          <main className="px-4 pt-4 md:px-6">
            <AnimatePresence mode="wait">
              <motion.div key={page} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}>
                {page === "dashboard" && <Dashboard onInvestigate={investigate} onSelectCamera={setCamera} onNav={nav} />}
                {page === "cameras" && <LiveCameras onSelectCamera={setCamera} />}
                {page === "search" && <SearchPage onInvestigate={investigate} initialPlate={searchPlate} />}
                {page === "trajectory" && <TrajectoryPage onInvestigate={investigate} />}
                {page === "analytics" && <AnalyticsPage />}
                {page === "alerts" && <AlertsPage onInvestigate={investigate} />}
                {page === "anpr" && <ANPRPage onInvestigate={investigate} />}
                {page === "network" && <NetworkPage onSelectCamera={setCamera} />}
                {page === "reports" && <ReportsPage />}
                {page === "settings" && <SettingsPage />}
              </motion.div>
            </AnimatePresence>

            <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[.06] py-5 text-[10px] font-bold tracking-wide text-white/25">
              <span>GUJARAT SENTINEL · AI-POWERED VEHICLE INTELLIGENCE · VADODARA SMART CITY</span>
              <span className="font-mono">DEMO BUILD · SIMULATED DATA · {new Date().toLocaleTimeString("en-IN", { hour12: false })}</span>
            </footer>
            <div className="h-20 lg:hidden" />
          </main>
        </div>
      </div>

      {/* mobile sidebar sheet */}
      <AnimatePresence>
        {mobileMenu && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileMenu(false)} className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm lg:hidden" />
            <motion.div initial={{ x: -300 }} animate={{ x: 0 }} exit={{ x: -300 }} transition={{ type: "spring", stiffness: 340, damping: 34 }} className="fixed left-0 top-0 z-[71] h-full w-[270px] overflow-y-auto border-r border-white/10 bg-[#08080c] p-4 lg:hidden">
              <div className="flex items-center justify-between px-1"><Logo /><button onClick={() => setMobileMenu(false)} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-lg"><X className="h-4 w-4" /></button></div>
              <nav className="mt-5 space-y-1">
                {[
                  ["dashboard", "Dashboard"], ["cameras", "Live Cameras"], ["search", "Vehicle Search"], ["trajectory", "Trajectory"],
                  ["analytics", "Traffic Analytics"], ["alerts", "Alerts"], ["anpr", "ANPR"], ["network", "Camera Network"], ["reports", "Reports"], ["settings", "Settings"],
                ].map(([id, label]) => (
                  <button key={id} onClick={() => nav(id)} className={cn("flex w-full items-center rounded-xl px-3.5 py-3 text-[13px] font-extrabold", page === id ? "bg-[#b8ff2e] text-black" : "text-white/50 hover:bg-white/[.05] hover:text-white")}>
                    {label}
                    {id === "alerts" && <span className="ml-auto rounded-full bg-[#ff3b4e] px-2 py-0.5 text-[10px] font-black text-white">10</span>}
                  </button>
                ))}
              </nav>
              <div className="mt-4 rounded-2xl border border-white/[.07] bg-white/[.02] p-3.5">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2"><span className="absolute h-full w-full animate-ping rounded-full bg-[#b8ff2e] opacity-60" /><span className="h-2 w-2 rounded-full bg-[#b8ff2e]" /></span>
                  <span className="text-[11px] font-extrabold text-[#d3ff7d]">ALL SYSTEMS OPERATIONAL</span>
                </div>
                <div className="mt-2.5 flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-[#2a2a35] to-[#15151c] text-[10px] font-black text-[#b8ff2e] ring-1 ring-white/10">{user.profile.initials}</div>
                  <div className="min-w-0 flex-1 leading-tight"><div className="truncate text-[12px] font-extrabold">{user.profile.name}</div><div className="truncate text-[10px] text-white/35">{user.profile.unit}</div></div>
                </div>
                <button onClick={logout} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff3b4e]/25 bg-[#ff3b4e]/[.06] py-2.5 text-[12px] font-extrabold text-[#ff8a95] transition hover:bg-[#ff3b4e]/[.12]"><LogOut className="h-4 w-4" /> Sign out</button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-[65] border-t border-white/10 bg-[#07070c]/95 backdrop-blur-xl lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="grid grid-cols-5">
          {MOBILE_NAV.map((n) => {
            const active = page === n.id;
            return (
              <button key={n.id} onClick={() => nav(n.id)} className="relative flex flex-col items-center gap-1 py-2.5">
                {active && <motion.span layoutId="mnav" className="absolute top-0 h-0.5 w-10 rounded-full bg-[#b8ff2e] shadow-[0_0_10px_#b8ff2e]" />}
                <n.icon className={cn("h-5 w-5", active ? "text-[#b8ff2e]" : "text-white/35")} />
                <span className={cn("text-[9px] font-extrabold tracking-wide", active ? "text-[#d3ff7d]" : "text-white/35")}>{n.label}</span>
                {n.id === "alerts" && <span className="absolute right-1/2 top-1.5 translate-x-5 rounded-full bg-[#ff3b4e] px-1 text-[8px] font-black text-white">10</span>}
              </button>
            );
          })}
        </div>
      </nav>

      <CameraPanel camera={camera} onClose={() => setCamera(null)} onInvestigate={investigate} />
      <InvestigationDrawer plate={plate} onClose={() => setPlate(null)} />
    </div>
  );
}
