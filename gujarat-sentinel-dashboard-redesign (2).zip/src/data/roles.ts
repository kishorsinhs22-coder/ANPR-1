export type RoleKey = "police" | "rto" | "government";

export interface RoleConfig {
  key: RoleKey;
  label: string;
  full: string;
  blurb: string;
  idLabel: string;
  idPlaceholder: string;
  demoId: string;
  scope: string[];
  profile: { name: string; initials: string; unit: string; salutation: string; badge: string };
}

export const ROLES: RoleConfig[] = [
  {
    key: "police",
    label: "Police",
    full: "Traffic & Crime Branch",
    blurb: "Live tracking, blacklist alerts and full vehicle investigations.",
    idLabel: "Badge ID",
    idPlaceholder: "e.g. VDR-TP-2041",
    demoId: "VDR-TP-2041",
    scope: ["Live ANPR feeds", "Investigations", "Blacklist alerts", "Evidence locker"],
    profile: { name: "Insp. R. Parmar", initials: "RP", unit: "Traffic Intelligence Unit", salutation: "Officer", badge: "POLICE" },
  },
  {
    key: "rto",
    label: "RTO",
    full: "Regional Transport Office",
    blurb: "Registration verification, plate-cloning checks and compliance reports.",
    idLabel: "RTO Employee ID",
    idPlaceholder: "e.g. RTO-GJ06-118",
    demoId: "RTO-GJ06-118",
    scope: ["Registration lookup", "Plate-cloning checks", "Violation batches", "Compliance reports"],
    profile: { name: "Sh. A. Desai", initials: "AD", unit: "RTO Vadodara · GJ-06", salutation: "Officer", badge: "RTO" },
  },
  {
    key: "government",
    label: "Government",
    full: "Smart City & State Govt.",
    blurb: "City-wide flow analytics, network health and policy reporting.",
    idLabel: "Govt. Official ID",
    idPlaceholder: "e.g. GOV-VSCL-007",
    demoId: "GOV-VSCL-007",
    scope: ["Traffic analytics", "Network health", "Policy reports", "Read-only oversight"],
    profile: { name: "Smt. K. Shah", initials: "KS", unit: "Vadodara Smart City Ltd.", salutation: "Administrator", badge: "GOVT" },
  },
];

export const getRole = (key: string | null | undefined) => ROLES.find((r) => r.key === key) ?? null;
