export type Risk = "critical" | "high" | "medium" | "low" | "normal";

export interface Camera {
  id: string;
  name: string;
  area: string;
  status: "online" | "degraded" | "offline";
  fps: number;
  anpr: number;
  x: number; // map coords 0-100
  y: number;
  lastDetection: string;
  plate?: string;
  feed?: string;
}

export interface Alert {
  id: string;
  plate: string;
  time: string;
  risk: Risk;
  location: string;
  trigger: string;
  camera: string;
  confidence: number;
  state?: string;
}

export interface TrajectoryStop {
  time: string;
  location: string;
  camera: string;
  gap: string;
  confidence: number;
  x: number;
  y: number;
}

export const RISK_META: Record<Risk, { label: string; dot: string; text: string; border: string; bg: string; action: string }> = {
  critical: { label: "Critical", dot: "bg-[#ff3b4e]", text: "text-[#ff6b7a]", border: "border-[#ff3b4e]/30", bg: "bg-[#ff3b4e]/10", action: "Investigate" },
  high: { label: "High", dot: "bg-[#ff8a2b]", text: "text-[#ffa25e]", border: "border-[#ff8a2b]/30", bg: "bg-[#ff8a2b]/10", action: "Analyze" },
  medium: { label: "Medium", dot: "bg-[#ffc93c]", text: "text-[#ffd97a]", border: "border-[#ffc93c]/30", bg: "bg-[#ffc93c]/10", action: "Review" },
  low: { label: "Low", dot: "bg-[#4ea8ff]", text: "text-[#7cc0ff]", border: "border-[#4ea8ff]/30", bg: "bg-[#4ea8ff]/10", action: "Verify" },
  normal: { label: "Normal", dot: "bg-[#b8ff2e]", text: "text-[#d3ff7d]", border: "border-[#b8ff2e]/30", bg: "bg-[#b8ff2e]/10", action: "View" },
};

export const CAMERAS: Camera[] = [
  { id: "CAM-RC-014", name: "Race Course Circle", area: "Race Course", status: "online", fps: 25, anpr: 95.4, x: 62, y: 34, lastDetection: "18:42:16", plate: "GJ-06-CD-5678" },
  { id: "CAM-AK-009", name: "Akota Bridge South", area: "Akota", status: "online", fps: 24, anpr: 94.2, x: 34, y: 58, lastDetection: "18:41:52", plate: "GJ-01-AB-4821" },
  { id: "CAM-SY-003", name: "Sayajigunj Junction", area: "Sayajigunj", status: "online", fps: 26, anpr: 96.1, x: 48, y: 30, lastDetection: "18:42:05", plate: "GJ-05-XY-9999" },
  { id: "CAM-WR-021", name: "Waghodia Rd Flyover", area: "Waghodia Rd", status: "degraded", fps: 12, anpr: 87.1, x: 78, y: 52, lastDetection: "18:38:44", plate: "GJ-06-QR-2210" },
  { id: "CAM-AP-007", name: "Alkapuri Circle", area: "Alkapuri", status: "online", fps: 25, anpr: 95.8, x: 42, y: 44, lastDetection: "18:42:11", plate: "GJ-06-CD-5678" },
  { id: "CAM-MJ-011", name: "Manjalpur Crossing", area: "Manjalpur", status: "online", fps: 23, anpr: 93.6, x: 66, y: 68, lastDetection: "18:41:37", plate: "MH-02-EF-1108" },
  { id: "CAM-GT-005", name: "Gotri Sevasi Rd", area: "Gotri", status: "online", fps: 25, anpr: 94.9, x: 22, y: 70, lastDetection: "18:42:01", plate: "GJ-06-MN-4412" },
  { id: "CAM-NM-002", name: "Nyay Mandir Gate", area: "Old City", status: "offline", fps: 0, anpr: 0, x: 52, y: 56, lastDetection: "17:55:02" },
  { id: "CAM-VS-017", name: "Vasna Tarsali Rd", area: "Vasna", status: "online", fps: 24, anpr: 92.8, x: 74, y: 78, lastDetection: "18:40:19", plate: "GJ-06-HJ-9034" },
  { id: "CAM-FG-001", name: "Fatehgunj Crossroads", area: "Fatehgunj", status: "online", fps: 27, anpr: 96.8, x: 38, y: 20, lastDetection: "18:42:20", plate: "GJ-06-CD-5678" },
  { id: "CAM-OP-026", name: "OP Road Entry", area: "OP Road", status: "online", fps: 25, anpr: 94.4, x: 56, y: 46, lastDetection: "18:41:48", plate: "GJ-01-RT-7788" },
  { id: "CAM-KD-030", name: "Karelibaug Tower", area: "Karelibaug", status: "degraded", fps: 14, anpr: 88.3, x: 60, y: 60, lastDetection: "18:39:12", plate: "GJ-06-PL-0091" },
];

export const ALERTS: Alert[] = [
  { id: "ALT-9041", plate: "GJ-05-XY-9999", time: "18:42", risk: "critical", location: "Race Course", trigger: "Blacklist Match", camera: "CAM-RC-014", confidence: 98.2 },
  { id: "ALT-9038", plate: "GJ-06-CD-5678", time: "18:35", risk: "high", location: "Akota", trigger: "Impossible Travel", camera: "CAM-AK-009", confidence: 91.4 },
  { id: "ALT-9031", plate: "GJ-01-AB-4821", time: "18:28", risk: "medium", location: "Sayajigunj", trigger: "Unusual Dwell · 42m", camera: "CAM-SY-003", confidence: 84.6 },
  { id: "ALT-9027", plate: "MH-02-EF-1108", time: "18:21", risk: "critical", location: "Waghodia Rd", trigger: "Stolen Vehicle Hit", camera: "CAM-WR-021", confidence: 97.1 },
  { id: "ALT-9022", plate: "GJ-06-QR-2210", time: "18:14", risk: "high", location: "Manjalpur", trigger: "Unusual Volume", camera: "CAM-MJ-011", confidence: 89.3 },
  { id: "ALT-9019", plate: "GJ-06-MN-4412", time: "18:07", risk: "medium", location: "Gotri", trigger: "Velocity Burst", camera: "CAM-GT-005", confidence: 82.9 },
  { id: "ALT-9014", plate: "GJ-01-RT-7788", time: "17:58", risk: "low", location: "OP Road", trigger: "First-time Corridor", camera: "CAM-OP-026", confidence: 76.4 },
  { id: "ALT-9009", plate: "GJ-06-HJ-9034", time: "17:51", risk: "high", location: "Vasna", trigger: "No-Entry Violation", camera: "CAM-VS-017", confidence: 90.2 },
];

export const FOCUS_VEHICLE = {
  plate: "GJ-06-CD-5678",
  type: "SUV · XUV700",
  color: "Lunar Black",
  risk: "medium" as Risk,
  status: "ACTIVE",
  lastSeen: "18:42:16",
  location: "Race Course Circle",
  speed: 42,
  direction: "North-East",
  detections: 24,
  firstSeen: "17:10",
  anprConfidence: 97.4,
  owner: "Flagged · Rental fleet",
};

export const TRAJECTORY: TrajectoryStop[] = [
  { time: "17:10", location: "Alkapuri Circle", camera: "CAM-AP-007", gap: "↓ 8 min", confidence: 97.8, x: 42, y: 44 },
  { time: "17:18", location: "Sayajigunj", camera: "CAM-SY-003", gap: "↓ 8 min", confidence: 96.4, x: 48, y: 30 },
  { time: "17:26", location: "Akota Bridge", camera: "CAM-AK-009", gap: "↓ 9 min", confidence: 95.1, x: 34, y: 58 },
  { time: "17:35", location: "Waghodia Road", camera: "CAM-WR-021", gap: "↓ 7 min", confidence: 91.7, x: 78, y: 52 },
  { time: "18:42", location: "Race Course Circle", camera: "CAM-RC-014", gap: "live", confidence: 98.4, x: 62, y: 34 },
];

export const RECENT_DETECTIONS = [
  { plate: "GJ-06-CD-5678", time: "18:42:16", cam: "CAM-RC-014", conf: 97.8, type: "SUV" },
  { plate: "GJ-05-XY-9999", time: "18:42:05", cam: "CAM-SY-003", conf: 98.2, type: "Sedan" },
  { plate: "GJ-01-AB-4821", time: "18:41:52", cam: "CAM-AK-009", conf: 95.6, type: "Hatchback" },
  { plate: "MH-02-EF-1108", time: "18:41:37", cam: "CAM-MJ-011", conf: 94.1, type: "SUV" },
  { plate: "GJ-06-MN-4412", time: "18:41:20", cam: "CAM-GT-005", conf: 96.9, type: "Sedan" },
  { plate: "GJ-01-RT-7788", time: "18:40:58", cam: "CAM-OP-026", conf: 93.4, type: "Truck" },
];

export const HOURLY_FLOW = [4200, 5100, 4800, 6200, 7800, 9400, 11200, 12800, 11500, 9800, 8600, 9200, 10400, 11800, 12482, 12100, 11600, 10800];
export const SPEED_SERIES = [48, 46, 44, 41, 38, 34, 31, 29, 32, 36, 39, 42, 38, 35, 34, 33, 36, 40];
export const CONGESTION_SERIES = [12, 14, 18, 24, 32, 41, 52, 64, 58, 44, 36, 40, 48, 55, 62, 58, 50, 38];
export const SPARK = [8, 9, 8, 10, 12, 11, 13, 15, 14, 16, 18, 17, 19, 21, 22, 24];

export const TOP_CORRIDORS = [
  { route: "Manjalpur → Alkapuri", volume: "8,412", speed: "28 km/h", load: 82 },
  { route: "Vasna → Gotri", volume: "6,980", speed: "34 km/h", load: 64 },
  { route: "Race Course → Nyay Mandir", volume: "6,204", speed: "22 km/h", load: 74 },
  { route: "Sayajigunj → Fatehgunj", volume: "5,311", speed: "41 km/h", load: 46 },
  { route: "Akota → OP Road", volume: "4,876", speed: "37 km/h", load: 52 },
];

export const CAM_FEEDS = [
  { id: "CAM-RC-014", name: "Race Course Circle", img: "https://images.pexels.com/photos/6307433/pexels-photo-6307433.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", status: "online", vehicles: 34 },
  { id: "CAM-SY-003", name: "Sayajigunj Junction", img: "https://images.pexels.com/photos/35069646/pexels-photo-35069646.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", status: "online", vehicles: 28 },
  { id: "CAM-AK-009", name: "Akota Bridge South", img: "https://images.pexels.com/photos/13795730/pexels-photo-13795730.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", status: "online", vehicles: 41 },
  { id: "CAM-MJ-011", name: "Manjalpur Crossing", img: "https://images.pexels.com/photos/30838933/pexels-photo-30838933.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", status: "online", vehicles: 22 },
  { id: "CAM-WR-021", name: "Waghodia Flyover", img: "https://images.pexels.com/photos/29105385/pexels-photo-29105385.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", status: "degraded", vehicles: 17 },
  { id: "CAM-GT-005", name: "Gotri Sevasi Rd", img: "https://images.pexels.com/photos/29188036/pexels-photo-29188036.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", status: "online", vehicles: 19 },
];

export const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard" },
  { id: "cameras", label: "Live Cameras" },
  { id: "search", label: "Vehicle Search" },
  { id: "trajectory", label: "Trajectory" },
  { id: "analytics", label: "Traffic Analytics" },
  { id: "alerts", label: "Alerts" },
  { id: "anpr", label: "ANPR" },
  { id: "network", label: "Camera Network" },
  { id: "reports", label: "Reports" },
  { id: "settings", label: "Settings" },
];
