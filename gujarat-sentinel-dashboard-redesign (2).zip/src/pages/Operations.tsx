import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Video, Maximize2, ScanLine, Camera, ChevronRight, Zap, CheckCircle2, AlertTriangle } from "lucide-react";
import { Card, Toggle, Progress, RiskDot } from "../components/ui";
import VadodaraMap from "../components/VadodaraMap";
import { CAMERAS, CAM_FEEDS, RECENT_DETECTIONS, type Camera as CamType } from "../data/mock";
import { cn } from "../utils/cn";

/* ---------------- LIVE CAMERAS ---------------- */
export function LiveCameras({ onSelectCamera }: { onSelectCamera: (c: CamType) => void }) {
  const [onlineOnly, setOnlineOnly] = useState(false);
  const feeds = onlineOnly ? CAM_FEEDS.filter((f) => f.status === "online") : CAM_FEEDS;
  return (
    <div className="space-y-4 pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-[22px] font-extrabold tracking-tight">Live Cameras</h2>
          <p className="text-[12px] font-semibold text-white/40">218 of 220 nodes streaming · Vadodara grid</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="rounded-lg bg-[#ffc93c]/10 px-2.5 py-1.5 text-[10px] font-black tracking-[.16em] text-[#ffd97a] ring-1 ring-[#ffc93c]/30">DEMO MODE · SIMULATED FEEDS</span>
          <span className="text-[11px] font-bold text-white/45">Online only</span>
          <Toggle on={onlineOnly} onChange={setOnlineOnly} />
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {feeds.map((f, i) => {
          const cam = CAMERAS.find((c) => c.id === f.id);
          return (
            <Card key={f.id} delay={i % 3} className="group cursor-pointer p-0" hover>
              <div className="relative h-52 overflow-hidden" onClick={() => cam && onSelectCamera(cam)}>
                <img src={f.img} alt={f.name} className="h-full w-full object-cover opacity-75 transition-transform duration-500 group-hover:scale-[1.04]" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/30" />
                <div className="absolute left-3 top-3 flex items-center gap-2">
                  <span className="rounded-md bg-black/70 px-2 py-1 font-mono text-[10px] font-bold text-white backdrop-blur">{f.id}</span>
                  {f.status === "online" ? (
                    <span className="flex items-center gap-1.5 rounded-md bg-black/70 px-2 py-1 text-[9px] font-black tracking-widest text-[#b8ff2e] backdrop-blur"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#b8ff2e]" />LIVE</span>
                  ) : (
                    <span className="flex items-center gap-1.5 rounded-md bg-black/70 px-2 py-1 text-[9px] font-black tracking-widest text-[#ffd97a] backdrop-blur"><span className="h-1.5 w-1.5 rounded-full bg-[#ffc93c]" />DEGRADED</span>
                  )}
                </div>
                <div className="scanline absolute inset-x-3 h-px bg-[#b8ff2e]/50" style={{ animationDelay: `${i * 0.7}s` }} />
                {/* detection boxes */}
                <div className="absolute left-[18%] top-[38%] h-12 w-24 rounded-sm border-2 border-[#b8ff2e]/80"><span className="absolute -top-5 left-0 whitespace-nowrap rounded bg-[#b8ff2e] px-1.5 py-0.5 font-mono text-[9px] font-black text-black">GJ-06-CD-56 · 97%</span></div>
                <div className="absolute right-[12%] top-[52%] h-10 w-20 rounded-sm border-2 border-[#4ea8ff]/70"><span className="absolute -top-5 left-0 whitespace-nowrap rounded bg-[#4ea8ff] px-1.5 py-0.5 font-mono text-[9px] font-black text-black">GJ-01-AB · 95%</span></div>
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-3.5">
                  <div><div className="text-[14px] font-extrabold text-white">{f.name}</div><div className="text-[11px] font-bold text-white/50">{cam?.fps ?? 24} FPS · {f.vehicles} vehicles in frame</div></div>
                  <span className="btn-ghost flex h-8 w-8 items-center justify-center rounded-lg !bg-black/60 backdrop-blur"><Maximize2 className="h-3.5 w-3.5" /></span>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- ANPR ---------------- */
export function ANPRPage({ onInvestigate }: { onInvestigate: (plate: string) => void }) {
  const [idx, setIdx] = useState(0);
  const [scanning, setScanning] = useState(true);
  const current = RECENT_DETECTIONS[idx % RECENT_DETECTIONS.length];

  useEffect(() => {
    const t = setInterval(() => { setScanning(true); setTimeout(() => { setIdx((i) => i + 1); setScanning(false); }, 900); }, 4200);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="space-y-4 pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-[22px] font-extrabold tracking-tight">ANPR Live Decode</h2>
          <p className="text-[12px] font-semibold text-white/40">Optical character recognition · 94.7% fleet accuracy</p>
        </div>
        <span className="rounded-lg bg-[#ffc93c]/10 px-2.5 py-1.5 text-[10px] font-black tracking-[.16em] text-[#ffd97a] ring-1 ring-[#ffc93c]/30">DEMO MODE · SIMULATED FEEDS</span>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        <Card className="overflow-hidden p-0 xl:col-span-7" hover={false}>
          <div className="flex items-center justify-between px-5 py-4">
            <div className="flex items-center gap-2.5">
              <span className="font-mono text-[13px] font-bold text-white">CAM-RC-014</span>
              <span className="flex items-center gap-1.5 rounded-full bg-[#b8ff2e]/10 px-2.5 py-1 text-[10px] font-black tracking-widest text-[#d3ff7d]"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#b8ff2e]" />LIVE</span>
            </div>
            <span className="font-mono text-[11px] text-white/40">Race Course Circle · North-East</span>
          </div>
          <div className="relative h-[380px] overflow-hidden md:h-[440px]">
            <img src="/images/anpr-feed.png" alt="ANPR feed" className="h-full w-full object-cover opacity-85" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />
            {/* OCR box */}
            <motion.div key={idx} initial={{ opacity: 0, scale: 1.08 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}
              className="absolute left-1/2 top-[30%] w-72 max-w-[80%] -translate-x-1/2">
              <div className={cn("rounded-lg border-2 p-3 backdrop-blur-[1px] transition-colors", scanning ? "border-[#4ea8ff]" : "border-[#b8ff2e] shadow-[0_0_30px_-6px_rgba(184,255,46,.6)]")}>
                <div className="flex items-center justify-center gap-2">
                  <span className="plate !text-[15px]">{scanning ? "READING…" : current.plate}</span>
                </div>
                <div className="mt-2 flex items-center justify-between font-mono text-[10px] font-bold">
                  <span className={scanning ? "text-[#8fc6ff]" : "text-[#d3ff7d]"}>{scanning ? "DECODING FRAMES" : `CONF ${current.conf}%`}</span>
                  <span className="text-white/60">{current.time}</span>
                </div>
              </div>
              {/* corner brackets */}
              {[["-left-2 -top-2 border-l-4 border-t-4", "rounded-tl-lg"], ["-right-2 -top-2 border-r-4 border-t-4", "rounded-tr-lg"], ["-bottom-2 -left-2 border-b-4 border-l-4", "rounded-bl-lg"], ["-bottom-2 -right-2 border-b-4 border-r-4", "rounded-br-lg"]].map(([pos, r], i) => (
                <span key={i} className={cn("absolute h-6 w-6 border-[#b8ff2e]", pos, r)} />
              ))}
            </motion.div>
            {scanning && <div className="scanline absolute inset-x-6 h-0.5 bg-[#4ea8ff]/70 shadow-[0_0_16px_#4ea8ff]" />}
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
              <div className="flex gap-2">
                {[["25 FPS", true], ["1080p", true], ["IR NIGHT", false]].map(([l, on]: any) => (
                  <span key={l} className={cn("rounded-md px-2 py-1 font-mono text-[10px] font-bold backdrop-blur", on ? "bg-black/70 text-white" : "bg-[#b8ff2e]/20 text-[#d3ff7d]")}>{l}</span>
                ))}
              </div>
              <span className="font-mono text-[11px] text-white/60">FRAME 8841{idx % 9}</span>
            </div>
          </div>
        </Card>

        <div className="space-y-4 xl:col-span-5">
          <Card className="p-5" hover={false}>
            <div className="label-caps flex items-center gap-2"><ScanLine className="h-3.5 w-3.5 text-[#b8ff2e]" /> Detection result</div>
            <div className="mt-3 text-center">
              <motion.span key={current.plate + idx} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="plate !px-5 !py-2 !text-[20px]">{current.plate}</motion.span>
              <div className="mt-2 flex items-center justify-center gap-1.5 text-[11px] font-extrabold text-[#d3ff7d]"><CheckCircle2 className="h-3.5 w-3.5" /> VERIFIED READ</div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2.5">
              {[
                ["OCR Confidence", `${current.conf}%`], ["Vehicle Type", current.type],
                ["Timestamp", current.time], ["Direction", "North-East"],
                ["Camera", current.cam], ["Lane", "Lane 2 · Fast"],
              ].map(([l, v]) => (
                <div key={l} className="rounded-xl border border-white/[.06] bg-white/[.02] p-3">
                  <div className="text-[9px] font-extrabold tracking-[.16em] text-white/35">{l.toUpperCase()}</div>
                  <div className="mt-1 text-[13px] font-extrabold text-white">{v}</div>
                </div>
              ))}
            </div>
            <button onClick={() => onInvestigate(current.plate)} className="btn-volt mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-[12px]">OPEN FULL INTELLIGENCE <ChevronRight className="h-4 w-4" /></button>
          </Card>

          <Card className="p-5" hover={false}>
            <div className="label-caps mb-3">Recent detections</div>
            <div className="space-y-2">
              {RECENT_DETECTIONS.map((d, i) => (
                <button key={i} onClick={() => onInvestigate(d.plate)} className={cn("flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-all hover:bg-white/[.04]", i === idx % RECENT_DETECTIONS.length ? "border-[#b8ff2e]/30 bg-[#b8ff2e]/[.05]" : "border-white/[.06] bg-white/[.015]")}>
                  <span className="plate !border-t-[3px] !px-2 !py-0.5 !text-[10px]">{d.plate}</span>
                  <span className="text-[11px] font-bold text-white/40">{d.type}</span>
                  <span className="ml-auto font-mono text-[11px] font-bold text-white/50">{d.time}</span>
                  <span className="font-mono text-[11px] font-bold text-[#d3ff7d]">{d.conf}%</span>
                </button>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ---------------- CAMERA NETWORK ---------------- */
export function NetworkPage({ onSelectCamera }: { onSelectCamera: (c: CamType) => void }) {
  const [sel, setSel] = useState<string | null>("CAM-RC-014");
  const [filter, setFilter] = useState("all");
  const list = CAMERAS.filter((c) => filter === "all" || c.status === filter);
  const selCam = CAMERAS.find((c) => c.id === sel);

  return (
    <div className="space-y-4 pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-[22px] font-extrabold tracking-tight">Camera Network</h2>
          <p className="text-[12px] font-semibold text-white/40">Control-room view · 218 / 220 online</p>
        </div>
        <div className="flex gap-1.5 rounded-xl bg-white/[.03] p-1">
          {[["all", "All"], ["online", "Online"], ["degraded", "Degraded"], ["offline", "Offline"]].map(([v, l]) => (
            <button key={v} onClick={() => setFilter(v)} className={cn("rounded-lg px-3 py-1.5 text-[11px] font-extrabold transition", filter === v ? "bg-[#b8ff2e] text-black" : "text-white/45 hover:text-white")}>{l}</button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        <Card className="p-4 md:p-5 xl:col-span-7" hover={false}>
          <div className="mb-3 flex items-center justify-between">
            <span className="label-caps !text-white/60">Grid topology · Vadodara</span>
            <span className="flex items-center gap-1.5 text-[11px] font-bold text-white/40"><Video className="h-3.5 w-3.5" /> {CAMERAS.length} nodes shown</span>
          </div>
          <VadodaraMap cameras={CAMERAS} selected={sel} showRoute={false} height={520}
            onSelect={(c) => { setSel(c.id); }} />
          {selCam && (
            <button onClick={() => onSelectCamera(selCam)} className="mt-3 flex w-full items-center justify-between rounded-xl border border-[#b8ff2e]/25 bg-[#b8ff2e]/[.05] px-4 py-3 text-left transition hover:bg-[#b8ff2e]/[.09]">
              <span><span className="font-mono text-[12px] font-bold text-white">{selCam.id}</span><span className="ml-2 text-[12px] font-bold text-white/50">{selCam.name}</span></span>
              <span className="flex items-center gap-1 text-[11px] font-extrabold text-[#d3ff7d]">OPEN FEED <ChevronRight className="h-4 w-4" /></span>
            </button>
          )}
        </Card>

        <div className="space-y-2.5 xl:col-span-5">
          <div className="grid grid-cols-3 gap-2.5">
            {[["ONLINE", "218", "#b8ff2e"], ["DEGRADED", "2", "#ffc93c"], ["OFFLINE", "1", "#ff3b4e"]].map(([l, v, c]) => (
              <Card key={l} className="p-3.5 text-center" hover={false}>
                <div className="text-[22px] font-black" style={{ color: c }}>{v}</div>
                <div className="text-[9px] font-extrabold tracking-[.18em] text-white/35">{l}</div>
              </Card>
            ))}
          </div>
          <div className="max-h-[560px] space-y-2 overflow-y-auto pr-1">
            {list.map((c, i) => (
              <motion.button key={c.id} initial={{ opacity: 0, x: 14 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: Math.min(i * 0.04, 0.4) }}
                onClick={() => { setSel(c.id); onSelectCamera(c); }}
                className={cn("card flex w-full items-center gap-3.5 p-3.5 text-left transition-all hover:border-[#b8ff2e]/25", sel === c.id && "!border-[#b8ff2e]/35 bg-[#b8ff2e]/[.03]")}>
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/[.04]"><Camera className="h-4.5 w-4.5 text-white/60" /></span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2"><span className="font-mono text-[12px] font-bold text-white">{c.id}</span><RiskDot risk={c.status} pulse={c.status !== "online"} /></span>
                  <span className="block truncate text-[11px] font-bold text-white/40">{c.name}</span>
                  <span className="mt-1.5 block"><Progress value={c.anpr || 4} color={c.status === "online" ? "#b8ff2e" : c.status === "degraded" ? "#ffc93c" : "#ff3b4e"} h="h-1" /></span>
                </span>
                <span className="shrink-0 text-right">
                  <span className="block font-mono text-[12px] font-bold text-white">{c.status === "offline" ? "—" : `${c.fps} FPS`}</span>
                  <span className="block text-[10px] font-bold text-white/40">{c.status === "offline" ? "NO SIGNAL" : `${c.anpr.toFixed(1)}% ANPR`}</span>
                </span>
              </motion.button>
            ))}
          </div>
          <div className="flex items-center gap-2 rounded-2xl border border-[#ffc93c]/20 bg-[#ffc93c]/[.05] p-3.5 text-[11.5px] font-bold text-white/60">
            <AlertTriangle className="h-4 w-4 shrink-0 text-[#ffd97a]" />
            <span><strong className="text-white">CAM-NM-002</strong> offline since 17:55 · maintenance unit dispatched <span className="text-[#ffd97a]">· ETA 22 min</span></span>
            <Zap className="ml-auto h-4 w-4 shrink-0 text-white/25" />
          </div>
        </div>
      </div>
    </div>
  );
}
