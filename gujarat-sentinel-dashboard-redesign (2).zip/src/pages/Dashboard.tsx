import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, ArrowUpRight, Eye, Radar, ShieldAlert, ScanLine, Video, Gauge, Bell, Activity, ChevronRight, Maximize2, Layers, Radio, MapPin, Clock, Zap, AlertTriangle } from "lucide-react";
import { Card, CountUp, LiveDot, Toggle, Progress, RiskDot, Pill, Stat } from "../components/ui";
import { Sparkline, Ring } from "../components/Charts";
import VadodaraMap from "../components/VadodaraMap";
import { CAMERAS, ALERTS, FOCUS_VEHICLE, TRAJECTORY, RISK_META, SPARK, type Camera as CamType } from "../data/mock";
import { cn } from "../utils/cn";

interface Props {
  onInvestigate: (plate: string) => void;
  onSelectCamera: (c: CamType) => void;
  onNav: (id: string) => void;
}

export default function Dashboard({ onInvestigate, onSelectCamera, onNav }: Props) {
  const [cityTotal, setCityTotal] = useState(184392);
  const [hourCount, setHourCount] = useState(12482);
  const [criticalOnly, setCriticalOnly] = useState(false);
  const [selectedCam, setSelectedCam] = useState<string | null>(null);
  const [density, setDensity] = useState("MEDIUM");

  useEffect(() => {
    const t = setInterval(() => {
      setCityTotal((v) => v + Math.floor(Math.random() * 7) + 2);
      if (Math.random() > 0.4) setHourCount((v) => v + 1);
    }, 1800);
    return () => clearInterval(t);
  }, []);

  const alerts = criticalOnly ? ALERTS.filter((a) => a.risk === "critical" || a.risk === "high") : ALERTS;

  return (
    <div className="space-y-4 pb-6">
      {/* greeting */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-[22px] font-extrabold tracking-tight md:text-[26px]">
            <span className="text-[22px]">👋</span> Good Morning, <span className="text-[#b8ff2e]">Officer</span>
          </h2>
          <p className="mt-0.5 text-[13px] font-semibold text-white/40">Vadodara Traffic Intelligence Center · See the movement. Understand the city.</p>
        </div>
        <button onClick={() => onNav("alerts")} className="group flex items-center gap-2.5 rounded-2xl border border-[#ff3b4e]/25 bg-[#ff3b4e]/[.06] py-2 pl-4 pr-2 transition-all hover:border-[#ff3b4e]/45 hover:bg-[#ff3b4e]/[.1]">
          <span className="relative flex h-2.5 w-2.5"><span className="absolute h-full w-full animate-ping rounded-full bg-[#ff3b4e] opacity-70" /><span className="h-2.5 w-2.5 rounded-full bg-[#ff3b4e]" /></span>
          <span className="text-[13px] font-bold text-white/80"><strong className="font-black text-white">10</strong> active investigations</span>
          <span className="flex items-center gap-1 rounded-xl bg-[#b8ff2e] px-3 py-1.5 text-[12px] font-black text-black transition-transform group-hover:translate-x-0.5">Investigate <ArrowRight className="h-3.5 w-3.5" /></span>
        </button>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <Card delay={0} className="p-5">
          <div className="flex items-center justify-between">
            <span className="label-caps">City traffic status</span>
            <span className="flex items-center gap-1.5 rounded-full bg-[#b8ff2e]/10 px-2.5 py-1 text-[10px] font-black tracking-widest text-[#d3ff7d]"><LiveDot /> LIVE</span>
          </div>
          <div className="mt-2 text-[40px] font-black leading-none tracking-tight text-white"><CountUp value={cityTotal} /></div>
          <div className="mt-1.5 text-[12px] font-bold text-white/40">Vehicles detected today</div>
          <div className="mt-4 flex items-end justify-between gap-3">
            <div>
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-white/50"><span className="h-1.5 w-1.5 rounded-full bg-[#b8ff2e]" /> Network Connected</div>
              <div className="mt-1.5 flex items-center gap-1.5">
                <span className="flex items-center gap-1 rounded-lg bg-[#b8ff2e]/10 px-2 py-1 text-[13px] font-black text-[#b8ff2e]"><ArrowUpRight className="h-3.5 w-3.5" />12.8%</span>
                <span className="text-[11px] font-bold text-white/35">vs yesterday</span>
              </div>
            </div>
            <Sparkline data={SPARK} />
          </div>
        </Card>

        <Card delay={1} className="p-5">
          <div className="flex items-center justify-between">
            <span className="label-caps flex items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#b8ff2e]/10"><Radar className="h-4 w-4 text-[#b8ff2e]" /></span> Live vehicle detections</span>
          </div>
          <div className="mt-2 text-[40px] font-black leading-none tracking-tight text-white"><CountUp value={hourCount} /></div>
          <div className="mt-1.5 text-[12px] font-bold text-white/40">Detections / Last Hour</div>
          <div className="mt-4 flex items-center justify-between rounded-xl border border-white/[.06] bg-white/[.02] px-3.5 py-2.5">
            <div><div className="text-[10px] font-extrabold tracking-widest text-white/35">ANPR ACCURACY</div><div className="text-[16px] font-black text-white">94.7%</div></div>
            <span className="flex items-center gap-1.5 text-[11px] font-black tracking-widest text-[#d3ff7d]"><LiveDot /> LIVE</span>
            <div className="flex gap-2">
              <button onClick={() => onNav("cameras")} className="btn-ghost rounded-lg px-3 py-1.5 text-[11px] font-extrabold">View Feed</button>
              <button onClick={() => onNav("analytics")} className="btn-volt rounded-lg px-3 py-1.5 text-[11px]">Analyze</button>
            </div>
          </div>
        </Card>

        <Card delay={2} className="p-5">
          <div className="flex items-center justify-between">
            <span className="label-caps flex items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#ff3b4e]/10"><ShieldAlert className="h-4 w-4 text-[#ff6b7a]" /></span> Active investigations</span>
            <button onClick={() => onNav("alerts")} className="flex items-center gap-1 text-[11px] font-extrabold text-white/40 transition hover:text-white">All <ChevronRight className="h-3.5 w-3.5" /></button>
          </div>
          <div className="mt-2 flex items-end gap-2">
            <span className="text-[40px] font-black leading-none tracking-tight text-white"><CountUp value={27} /></span>
            <span className="pb-1 text-[12px] font-bold text-white/40">Suspicious vehicles</span>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {[["Critical", "04", "#ff3b4e"], ["High", "09", "#ff8a2b"], ["Medium", "14", "#ffc93c"]].map(([l, v, c]) => (
              <div key={l} className="rounded-xl border border-white/[.06] bg-white/[.02] p-2.5 text-center">
                <div className="text-[20px] font-black tabular-nums" style={{ color: c }}>{v}</div>
                <div className="text-[9px] font-extrabold tracking-[.16em] text-white/35">{l.toUpperCase()}</div>
              </div>
            ))}
          </div>
          <button onClick={() => onInvestigate("GJ-05-XY-9999")} className="btn-volt mt-3 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-[12px]">INVESTIGATE <ArrowRight className="h-4 w-4" /></button>
        </Card>
      </div>

      {/* map + vehicle intel */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        <Card delay={1} className="p-4 md:p-5 xl:col-span-8">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <span className="label-caps !text-white/60">Live Vadodara network</span>
              <span className="flex items-center gap-1.5 rounded-full bg-[#b8ff2e]/10 px-2.5 py-1 text-[10px] font-black tracking-widest text-[#d3ff7d]"><LiveDot /> LIVE</span>
            </div>
            <div className="flex items-center gap-2">
              <button className="btn-ghost flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11px] font-extrabold"><Layers className="h-3.5 w-3.5" /> Layers</button>
              <button className="btn-ghost flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11px] font-extrabold"><Maximize2 className="h-3.5 w-3.5" /> Fullscreen</button>
            </div>
          </div>
          <div className="relative">
            <VadodaraMap cameras={CAMERAS} route={TRAJECTORY} selected={selectedCam} onSelect={(c) => { setSelectedCam(c.id); onSelectCamera(c); }} height={440} />
            {/* floating density card */}
            <div className="absolute bottom-3 left-3 w-44 rounded-2xl border border-white/10 bg-[#0a0a0e]/92 p-3 shadow-2xl backdrop-blur-xl">
              <div className="text-[9px] font-extrabold tracking-[.2em] text-white/40">TRAFFIC DENSITY</div>
              <div className="mt-2 space-y-1">
                {["LOW", "MEDIUM", "HIGH"].map((d) => (
                  <button key={d} onClick={() => setDensity(d)}
                    className={cn("flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-[10px] font-black tracking-widest transition-all",
                      density === d ? "bg-[#b8ff2e]/15 text-[#d3ff7d] ring-1 ring-[#b8ff2e]/30" : "text-white/35 hover:bg-white/[.04] hover:text-white/70")}>
                    <span className={cn("h-1.5 w-1.5 rounded-full", d === "LOW" ? "bg-[#b8ff2e]" : d === "MEDIUM" ? "bg-[#ffc93c]" : "bg-[#ff3b4e]")} /> {d}
                  </button>
                ))}
              </div>
            </div>
            {/* floating legend */}
            <div className="absolute right-3 top-3 flex items-center gap-3 rounded-xl border border-white/10 bg-[#0a0a0e]/92 px-3 py-2 backdrop-blur-xl">
              {[["Online", "#b8ff2e"], ["Degraded", "#ffc93c"], ["Offline", "#ff3b4e"]].map(([l, c]) => (
                <span key={l} className="flex items-center gap-1.5 text-[10px] font-extrabold tracking-wide text-white/60">
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: c, boxShadow: `0 0 8px ${c}` }} />{l}
                </span>
              ))}
            </div>
            {/* route chip */}
            <div className="absolute left-3 top-3 flex items-center gap-2 rounded-xl border border-[#b8ff2e]/25 bg-[#0a0a0e]/92 px-3 py-2 backdrop-blur-xl">
              <Radio className="h-3.5 w-3.5 text-[#b8ff2e]" />
              <span className="font-mono text-[11px] font-bold text-white">GJ-06-CD-5678</span>
              <span className="text-[10px] font-black tracking-widest text-[#d3ff7d]">TRACKING</span>
            </div>
          </div>
          {/* trajectory strip */}
          <div className="mt-3 flex items-center gap-2 overflow-x-auto rounded-2xl border border-white/[.06] bg-white/[.015] p-3 no-scrollbar">
            <span className="label-caps shrink-0 pl-1">Live<br />trajectory</span>
            <div className="mx-1 h-8 w-px shrink-0 bg-white/10" />
            {TRAJECTORY.slice(0, 4).map((s, i) => (
              <div key={i} className="flex shrink-0 items-center gap-2">
                <div className="rounded-xl border border-white/[.06] bg-[#101016] px-3 py-2">
                  <div className="font-mono text-[11px] font-bold text-[#d3ff7d]">{s.time}</div>
                  <div className="whitespace-nowrap text-[12px] font-extrabold text-white">{s.location}</div>
                </div>
                {i < 3 && <div className="flex flex-col items-center gap-0.5 px-0.5"><ChevronRight className="h-4 w-4 text-[#b8ff2e]" /><span className="text-[9px] font-bold text-white/30">{s.gap.replace("↓ ", "")}</span></div>}
              </div>
            ))}
            <button onClick={() => onNav("trajectory")} className="btn-ghost ml-auto flex shrink-0 items-center gap-1 rounded-xl px-3 py-2 text-[11px] font-extrabold">Full replay <ArrowRight className="h-3.5 w-3.5" /></button>
          </div>
        </Card>

        {/* vehicle intelligence */}
        <Card delay={2} className="flex flex-col p-5 xl:col-span-4">
          <div className="flex items-center justify-between">
            <span className="label-caps !text-white/60">Vehicle intelligence</span>
            <button onClick={() => onNav("search")} className="flex items-center gap-1 text-[11px] font-extrabold text-white/40 transition hover:text-white">Details <ChevronRight className="h-3.5 w-3.5" /></button>
          </div>
          <div className="mt-3 flex items-center justify-between">
            <span className="plate text-[15px]">{FOCUS_VEHICLE.plate}</span>
            <span className="flex items-center gap-1.5 rounded-full border border-[#b8ff2e]/25 bg-[#b8ff2e]/[.07] px-3 py-1 text-[10px] font-black tracking-[.16em] text-[#d3ff7d]"><LiveDot /> ACTIVE</span>
          </div>
          <button onClick={() => onInvestigate(FOCUS_VEHICLE.plate)} className="group relative mt-3 overflow-hidden rounded-2xl border border-white/[.07]">
            <img src="/images/suspect-vehicle.png" alt="tracked vehicle" className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
            <div className="absolute inset-x-0 bottom-0 flex items-center justify-between p-3">
              <div className="text-left"><div className="text-[12px] font-extrabold text-white">{FOCUS_VEHICLE.type}</div><div className="text-[10px] font-bold text-white/50">{FOCUS_VEHICLE.color}</div></div>
              <span className="flex items-center gap-1 rounded-lg bg-[#b8ff2e] px-2.5 py-1.5 text-[10px] font-black text-black"><Eye className="h-3 w-3" /> INSPECT</span>
            </div>
            <span className="absolute left-3 top-3 rounded-md bg-black/70 px-2 py-1 text-[9px] font-black tracking-[.18em] text-white/70 backdrop-blur">AI TRACK LOCK</span>
          </button>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              [<Clock key="c" className="h-3.5 w-3.5" />, "Last Seen", FOCUS_VEHICLE.lastSeen],
              [<MapPin key="m" className="h-3.5 w-3.5" />, "Location", "Race Course"],
              [<Gauge key="g" className="h-3.5 w-3.5" />, "Speed", `${FOCUS_VEHICLE.speed} km/h`],
              [<AlertTriangle key="a" className="h-3.5 w-3.5" />, "Risk", "MEDIUM"],
            ].map(([icon, l, v]: any, i) => (
              <div key={i} className="rounded-xl border border-white/[.06] bg-white/[.02] p-2.5">
                <div className="text-[#b8ff2e]">{icon}</div>
                <div className="mt-1.5 text-[8.5px] font-extrabold tracking-[.14em] text-white/35">{String(l).toUpperCase()}</div>
                <div className={cn("mt-0.5 truncate text-[11.5px] font-extrabold", i === 3 ? "text-[#ffd97a]" : "text-white")}>{v}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button onClick={() => onNav("trajectory")} className="btn-ghost rounded-xl py-2.5 text-[12px] font-extrabold">Track Vehicle</button>
            <button onClick={() => onInvestigate(FOCUS_VEHICLE.plate)} className="btn-volt rounded-xl py-2.5 text-[12px]">Open Investigation</button>
          </div>
          <div className="mt-3 rounded-xl border border-[#ffc93c]/20 bg-[#ffc93c]/[.05] p-3 text-[11px] font-bold leading-relaxed text-white/60">
            <span className="font-black text-[#ffd97a]">⚠ Route anomaly:</span> expected 12–18 min, observed 2 min · confidence 91%
          </div>
        </Card>
      </div>

      {/* alerts + right stack */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        <Card delay={1} className="p-5 xl:col-span-8">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-[17px] font-extrabold tracking-tight text-white">Recent Alerts</h3>
            <div className="flex items-center gap-3">
              <button onClick={() => onNav("alerts")} className="text-[11px] font-extrabold text-white/40 transition hover:text-white">View all →</button>
              <span className="text-[11px] font-bold text-white/45">Critical only</span>
              <Toggle on={criticalOnly} onChange={setCriticalOnly} />
            </div>
          </div>
          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full min-w-[640px] text-left">
              <thead>
                <tr className="text-[10px] font-extrabold tracking-[.16em] text-white/30">
                  <th className="pb-3 pr-4 font-extrabold">VEHICLE</th>
                  <th className="pb-3 pr-4 font-extrabold">TIME</th>
                  <th className="pb-3 pr-4 font-extrabold">RISK</th>
                  <th className="pb-3 pr-4 font-extrabold">LOCATION</th>
                  <th className="hidden pb-3 pr-4 font-extrabold lg:table-cell">TRIGGER</th>
                  <th className="pb-3 text-right font-extrabold">ACTION</th>
                </tr>
              </thead>
              <tbody>
                {alerts.slice(0, 6).map((a, i) => {
                  const m = RISK_META[a.risk];
                  return (
                    <motion.tr key={a.id} initial={{ opacity: 0, x: -12 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                      className="group cursor-pointer border-t border-white/[.05] transition-colors hover:bg-white/[.02]" onClick={() => onInvestigate(a.plate)}>
                      <td className="py-3 pr-4"><span className="font-mono text-[12.5px] font-bold text-[#8fc6ff] group-hover:text-white">{a.plate}</span><div className="font-mono text-[10px] text-white/30">{a.id}</div></td>
                      <td className="py-3 pr-4 font-mono text-[12px] font-bold text-white/60">{a.time}</td>
                      <td className="py-3 pr-4"><span className={cn("flex items-center gap-1.5 text-[12px] font-extrabold", m.text)}><RiskDot risk={a.risk} pulse={a.risk === "critical"} />{m.label}</span></td>
                      <td className="py-3 pr-4 text-[12px] font-bold text-white/60">{a.location}</td>
                      <td className="hidden py-3 pr-4 text-[12px] font-semibold text-white/45 lg:table-cell">{a.trigger}</td>
                      <td className="py-3 text-right">
                        <Pill tone={a.risk === "critical" ? "red" : a.risk === "high" ? "orange" : a.risk === "medium" ? "yellow" : "blue"}>{m.action}</Pill>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="mt-2 flex items-center justify-between border-t border-white/[.05] pt-3 text-[11px] font-bold text-white/30">
            <span>Showing 1 to 6 of 100 entries</span>
            <div className="flex gap-1.5">
              {["Prev", "1", "2", "3", "Next"].map((p, i) => (
                <button key={p} className={cn("rounded-lg px-2.5 py-1.5 text-[11px] font-extrabold transition", i === 1 ? "bg-[#b8ff2e] text-black" : "bg-white/[.04] text-white/50 hover:bg-white/10")}>{p}</button>
              ))}
            </div>
          </div>
        </Card>

        <div className="space-y-4 xl:col-span-4">
          <Card delay={2} className="p-5">
            <div className="label-caps mb-3">System health</div>
            {[["ANPR Engine", "94.7%", 94.7], ["Camera Network", "99.1%", 99.1], ["API Gateway", "98.8%", 98.8], ["Database", "100%", 100]].map(([l, v, p]: any) => (
              <div key={l} className="mb-2.5 flex items-center gap-2.5 last:mb-0">
                <span className="w-28 shrink-0 text-[11.5px] font-bold text-white/55">{l}</span>
                <div className="flex-1"><Progress value={p} color={p > 95 ? "#b8ff2e" : "#ffc93c"} h="h-1" /></div>
                <span className="flex w-14 shrink-0 items-center justify-end gap-1.5 font-mono text-[11.5px] font-bold text-white"><RiskDot risk="online" />{v}</span>
              </div>
            ))}
          </Card>
          <Card delay={3} className="p-5">
            <div className="label-caps">Camera network</div>
            <div className="mt-2 flex items-end justify-between">
              <div className="text-[26px] font-black text-white"><CountUp value={218} /> <span className="text-[13px] font-bold text-white/35">/ 220 Online</span></div>
            </div>
            <div className="mt-2.5"><Progress value={99.1} /></div>
            <div className="mt-2 text-[11px] font-bold text-white/40"><span className="text-[#ffd97a]">2 cameras</span> require attention</div>
            <button onClick={() => onNav("network")} className="btn-ghost mt-3 w-full rounded-xl py-2.5 text-[12px] font-extrabold">View Network</button>
          </Card>
          <Card delay={4} className="p-5">
            <div className="label-caps mb-3">Traffic status</div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <Stat label="City Avg" value="34 km/h" />
              <Stat label="Congestion" value="18%" accent="#ffc93c" />
              <Stat label="Incidents" value="06" accent="#ff6b7a" />
            </div>
            <div className="mt-3 flex items-center gap-2 rounded-xl bg-[#ff3b4e]/[.07] px-3 py-2.5 text-[11px] font-bold text-white/60 ring-1 ring-[#ff3b4e]/20">
              <Zap className="h-3.5 w-3.5 text-[#ff8a2b]" /> Heavy congestion · Race Course → Nyay Mandir
            </div>
          </Card>
        </div>
      </div>

      {/* bottom strip */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {[
          [<Activity key="a" className="h-5 w-5" />, "TRAFFIC DENSITY", "68%", "#b8ff2e"],
          [<Gauge key="g" className="h-5 w-5" />, "AVERAGE SPEED", "34 km/h", "#4ea8ff"],
          [<Video key="v" className="h-5 w-5" />, "CAMERAS", "218 Online", "#b8ff2e"],
          [<ScanLine key="s" className="h-5 w-5" />, "ANPR", "94.7%", "#b8ff2e"],
          [<Bell key="b" className="h-5 w-5" />, "ALERTS", "10 Active", "#ff6b7a"],
          [<Radio key="r" className="h-5 w-5" />, "NETWORK", "31 ms", "#4ea8ff"],
        ].map(([icon, l, v, c]: any, i) => (
          <Card key={i} delay={i} className="flex items-center gap-3 p-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl" style={{ background: `${c}14`, color: c }}>{icon}</span>
            <span><span className="block text-[9px] font-extrabold tracking-[.18em] text-white/35">{l}</span><span className="block text-[16px] font-black text-white">{v}</span></span>
          </Card>
        ))}
      </div>

      {/* mini intel row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card delay={1} className="flex items-center gap-4 p-4">
          <Ring value={68} size={72} color="#ffc93c"><span className="text-[13px] font-black">68%</span></Ring>
          <div><div className="label-caps">Corridor load</div><div className="mt-1 text-[14px] font-extrabold text-white">Manjalpur → Alkapuri</div><div className="text-[11px] font-bold text-white/40">8,412 veh/h · slowest corridor</div></div>
        </Card>
        <Card delay={2} className="flex items-center gap-4 p-4">
          <Ring value={94} size={72}><span className="text-[13px] font-black">94%</span></Ring>
          <div><div className="label-caps">ANPR precision</div><div className="mt-1 text-[14px] font-extrabold text-white">12,482 reads / hour</div><div className="text-[11px] font-bold text-white/40">0.8% re-read rate · nominal</div></div>
        </Card>
        <Card delay={3} className="flex items-center gap-4 p-4">
          <Ring value={24} size={72} color="#ff8a2b"><span className="text-[13px] font-black">6</span></Ring>
          <div><div className="label-caps">Open incidents</div><div className="mt-1 text-[14px] font-extrabold text-white">2 congestion · 4 violations</div><div className="text-[11px] font-bold text-white/40">Nearest unit 6 min away</div></div>
        </Card>
      </div>
    </div>
  );
}
