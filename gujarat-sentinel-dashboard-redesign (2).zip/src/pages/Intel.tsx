import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, ScanSearch, Play, Pause, ChevronRight, MapPin, Clock, Gauge, AlertTriangle, Download, FileText, Bell, SlidersHorizontal, ShieldAlert, CheckCircle2, Zap } from "lucide-react";
import { Card, Toggle, Progress, RiskDot, Pill, Stat, CountUp } from "../components/ui";
import { AreaChart, BarChart, Gauge as GaugeChart } from "../components/Charts";
import VadodaraMap from "../components/VadodaraMap";
import { CAMERAS, ALERTS, FOCUS_VEHICLE, TRAJECTORY, RISK_META, HOURLY_FLOW, SPEED_SERIES, CONGESTION_SERIES, TOP_CORRIDORS, type Camera as CamType } from "../data/mock";
import { cn } from "../utils/cn";

/* ============ VEHICLE SEARCH ============ */
export function SearchPage({ onInvestigate, initialPlate }: { onInvestigate: (p: string) => void; initialPlate: string }) {
  const [q, setQ] = useState(initialPlate || "GJ-06-CD-5678");
  const [searched, setSearched] = useState(!!initialPlate);
  const [scanning, setScanning] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { if (initialPlate) { setQ(initialPlate); run(initialPlate); } }, [initialPlate]);

  const run = (plate: string) => {
    if (!plate.trim()) return;
    setScanning(true); setSearched(false);
    setTimeout(() => { setScanning(false); setSearched(true); }, 1400);
  };

  return (
    <div className="space-y-4 pb-6">
      <div className="text-center">
        <h2 className="text-[24px] font-extrabold tracking-tight md:text-[28px]">Vehicle <span className="text-[#b8ff2e]">Search</span></h2>
        <p className="mt-1 text-[12px] font-semibold text-white/40">Query 220 ANPR nodes · 90-day trajectory history · sub-second lookup</p>
      </div>

      <Card className="mx-auto max-w-3xl p-5 md:p-7" hover={false}>
        <div className="relative">
          <div className={cn("flex items-center gap-3 rounded-2xl border bg-black/40 p-2 pl-5 transition-all", scanning ? "border-[#4ea8ff]/50 shadow-[0_0_50px_-10px_rgba(78,168,255,.5)]" : "border-[#b8ff2e]/30 shadow-[0_0_50px_-12px_rgba(184,255,46,.45)]")}>
            <ScanSearch className={cn("h-5 w-5 shrink-0", scanning ? "text-[#8fc6ff]" : "text-[#b8ff2e]")} />
            <input ref={inputRef} value={q} onChange={(e) => setQ(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && run(q)}
              placeholder="Enter vehicle number…" className="w-full min-w-0 flex-1 bg-transparent font-mono text-[15px] font-bold tracking-wider text-white placeholder:font-sans placeholder:text-[13px] placeholder:font-semibold placeholder:text-white/25 placeholder:tracking-normal focus:outline-none md:text-[18px]" />
            <button onClick={() => run(q)} disabled={scanning} className="btn-volt flex shrink-0 items-center gap-2 rounded-xl px-4 py-3 text-[12px] disabled:opacity-60 md:px-5 md:text-[13px]">
              {scanning ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-black/30 border-t-black" /> : <Search className="h-4 w-4" />}
              {scanning ? "SCANNING" : <><span className="hidden sm:inline">SEARCH VEHICLE</span><span className="sm:hidden">SEARCH</span></>}
            </button>
          </div>
          {scanning && <div className="scanline absolute inset-x-6 h-px bg-[#4ea8ff]/70" />}
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          <span className="text-[11px] font-bold text-white/35">Try:</span>
          {["GJ-06-CD-5678", "GJ-05-XY-9999", "GJ-01-AB-4821", "MH-02-EF-1108"].map((p) => (
            <button key={p} onClick={() => { setQ(p); run(p); }} className="rounded-lg border border-white/10 bg-white/[.03] px-2.5 py-1.5 font-mono text-[11px] font-bold text-white/60 transition hover:border-[#b8ff2e]/40 hover:text-white">{p}</button>
          ))}
        </div>
      </Card>

      <AnimatePresence mode="wait">
        {searched && !scanning && (
          <motion.div key={q} initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }} className="space-y-4">
            <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
              {[
                ["Vehicle", q], ["Detections", "24"], ["Last Seen", "Race Course"], ["Risk", "Medium"], ["Trajectory", "4 locations"],
              ].map(([l, v], i) => (
                <Card key={l} delay={i} className="p-4 text-center">
                  <div className="text-[9px] font-extrabold tracking-[.18em] text-white/35">{l.toUpperCase()}</div>
                  <div className={cn("mt-1.5 truncate font-mono text-[15px] font-black", l === "Risk" ? "font-sans text-[#ffd97a]" : "text-white")}>{v}</div>
                </Card>
              ))}
            </div>
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
              <Card className="p-4 md:p-5 xl:col-span-8" hover={false}>
                <div className="mb-3 flex items-center justify-between">
                  <span className="label-caps !text-white/60">Reconstructed path · last 2 hours</span>
                  <Pill tone="volt"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#b8ff2e]" /> 5 sightings</Pill>
                </div>
                <VadodaraMap cameras={CAMERAS} route={TRAJECTORY} height={400} />
              </Card>
              <div className="space-y-4 xl:col-span-4">
                <Card className="overflow-hidden p-0" hover={false}>
                  <img src="/images/suspect-vehicle.png" alt="vehicle" className="h-40 w-full object-cover" />
                  <div className="p-4">
                    <div className="flex items-center justify-between"><span className="plate text-[13px]">{q}</span><span className="flex items-center gap-1.5 text-[11px] font-extrabold text-[#ffd97a]"><RiskDot risk="medium" />MEDIUM</span></div>
                    <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
                      {[["Type", "SUV · XUV700"], ["Color", "Lunar Black"], ["First seen", "17:10"], ["ANPR conf.", "97.4%"]].map(([l, v]) => (
                        <div key={l} className="rounded-lg bg-white/[.03] p-2.5"><div className="text-[9px] font-extrabold tracking-widest text-white/35">{l.toUpperCase()}</div><div className="mt-0.5 font-extrabold text-white">{v}</div></div>
                      ))}
                    </div>
                    <button onClick={() => onInvestigate(q)} className="btn-volt mt-3 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-[12px]">OPEN INVESTIGATION <ChevronRight className="h-4 w-4" /></button>
                  </div>
                </Card>
                <Card className="p-4" hover={false}>
                  <div className="label-caps mb-2">Sightings</div>
                  {TRAJECTORY.slice(0, 4).map((s, i) => (
                    <div key={i} className="flex items-center gap-3 border-b border-white/[.05] py-2 last:border-0">
                      <span className="font-mono text-[11px] font-bold text-[#d3ff7d]">{s.time}</span>
                      <span className="flex-1 text-[12px] font-extrabold text-white">{s.location}</span>
                      <span className="font-mono text-[10px] text-white/40">{s.confidence}%</span>
                    </div>
                  ))}
                </Card>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ============ TRAJECTORY ============ */
export function TrajectoryPage({ onInvestigate }: { onInvestigate: (p: string) => void }) {
  const [playing, setPlaying] = useState(true);
  const [progress, setProgress] = useState(0.65);
  const [speed, setSpeed] = useState("1×");

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setProgress((p) => (p >= 1 ? 0 : p + 0.004)), 60);
    return () => clearInterval(t);
  }, [playing]);

  const activeIdx = Math.min(TRAJECTORY.length - 1, Math.floor(progress * TRAJECTORY.length));
  const visibleRoute = useMemo(() => TRAJECTORY.slice(0, activeIdx + 1), [activeIdx]);

  return (
    <div className="space-y-4 pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-[22px] font-extrabold tracking-tight">Trajectory Reconstruction</h2>
          <p className="text-[12px] font-semibold text-white/40">AI path stitching across ANPR nodes · gap interpolation active</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="plate !text-[12px]">{FOCUS_VEHICLE.plate}</span>
          <button onClick={() => onInvestigate(FOCUS_VEHICLE.plate)} className="btn-volt rounded-xl px-4 py-2 text-[12px]">Investigate</button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        <Card className="p-4 md:p-5 xl:col-span-8" hover={false}>
          <div className="mb-3 flex items-center justify-between">
            <span className="label-caps !text-white/60">Live vehicle trajectory · replay</span>
            <div className="flex items-center gap-2">
              {["0.5×", "1×", "2×", "4×"].map((s) => (
                <button key={s} onClick={() => setSpeed(s)} className={cn("rounded-lg px-2.5 py-1 font-mono text-[11px] font-bold transition", speed === s ? "bg-[#b8ff2e] text-black" : "bg-white/[.05] text-white/50 hover:text-white")}>{s}</button>
              ))}
            </div>
          </div>
          <VadodaraMap cameras={CAMERAS} route={visibleRoute.length > 1 ? visibleRoute : TRAJECTORY} height={460} />
          <div className="mt-4 rounded-2xl border border-white/[.06] bg-white/[.015] p-4">
            <div className="flex items-center gap-3">
              <button onClick={() => setPlaying(!playing)} className="btn-volt flex h-11 w-11 shrink-0 items-center justify-center !rounded-full">
                {playing ? <Pause className="h-4 w-4 fill-black" /> : <Play className="ml-0.5 h-4 w-4 fill-black" />}
              </button>
              <div className="flex-1">
                <input type="range" min={0} max={1000} value={progress * 1000} onChange={(e) => setProgress(Number(e.target.value) / 1000)}
                  className="w-full accent-[#b8ff2e]" />
                <div className="flex justify-between font-mono text-[10px] font-bold text-white/35"><span>17:10 · Alkapuri</span><span className="text-[#d3ff7d]">{TRAJECTORY[activeIdx]?.time} · {TRAJECTORY[activeIdx]?.location}</span><span>18:42 · Race Course</span></div>
              </div>
            </div>
          </div>
        </Card>

        <div className="xl:col-span-4">
          <Card className="p-5" hover={false}>
            <div className="label-caps mb-4">Detection sequence</div>
            <div>
              {TRAJECTORY.map((s, i) => {
                const done = i <= activeIdx;
                return (
                  <div key={i}>
                    <div className={cn("flex gap-3.5 rounded-2xl border p-3.5 transition-all", done ? "border-[#b8ff2e]/25 bg-[#b8ff2e]/[.04]" : "border-white/[.06] bg-white/[.015] opacity-60")}>
                      <span className={cn("mt-0.5 h-3 w-3 shrink-0 rounded-full", done ? "bg-[#b8ff2e] shadow-[0_0_12px_#b8ff2e]" : "bg-white/20")} />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className={cn("font-mono text-[13px] font-bold", done ? "text-[#d3ff7d]" : "text-white/40")}>{s.time}</span>
                          <span className="font-mono text-[10px] text-white/35">{s.confidence}%</span>
                        </div>
                        <div className="text-[14px] font-extrabold text-white">{s.location}</div>
                        <div className="text-[11px] font-semibold text-white/40">{s.camera}</div>
                      </div>
                    </div>
                    {i < TRAJECTORY.length - 1 && (
                      <div className="flex items-center gap-2 py-1.5 pl-[22px]">
                        <span className={cn("h-6 w-px", i < activeIdx ? "bg-[#b8ff2e]/60" : "bg-white/10")} />
                        <span className="text-[10px] font-extrabold tracking-widest text-white/30">{s.gap === "live" ? "● LIVE" : s.gap.replace("↓ ", "TRANSIT ")}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              {[["Distance", "14.2 km"], ["Avg speed", "38 km/h"], ["Stops", "1 · 42m"]].map(([l, v]) => (
                <div key={l} className="rounded-xl bg-white/[.03] p-2.5"><div className="text-[8.5px] font-extrabold tracking-widest text-white/35">{l.toUpperCase()}</div><div className="mt-0.5 text-[12px] font-black text-white">{v}</div></div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ============ ANALYTICS ============ */
const HOURS = ["06", "08", "10", "12", "14", "16", "18", "Now"];
export function AnalyticsPage() {
  return (
    <div className="space-y-4 pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-[22px] font-extrabold tracking-tight">Traffic Analytics</h2>
          <p className="text-[12px] font-semibold text-white/40">City-wide flow intelligence · updated 12s ago</p>
        </div>
        <div className="flex gap-1.5 rounded-xl bg-white/[.03] p-1">
          {["Live", "24H", "7D"].map((t, i) => (
            <button key={t} className={cn("rounded-lg px-4 py-1.5 text-[11px] font-extrabold", i === 0 ? "bg-[#b8ff2e] text-black" : "text-white/45 hover:text-white")}>{t}</button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {[
          ["Vehicles / hour", "12,482", "+8.2%", "#b8ff2e"],
          ["Average speed", "34 km/h", "-3.1%", "#4ea8ff"],
          ["Congestion index", "18%", "+2.4 pts", "#ffc93c"],
          ["Incidents today", "23", "-4 vs avg", "#ff8a2b"],
        ].map(([l, v, d, c], i) => (
          <Card key={l} delay={i} className="p-4">
            <div className="text-[9px] font-extrabold tracking-[.18em] text-white/35">{String(l).toUpperCase()}</div>
            <div className="mt-1 text-[24px] font-black text-white">{v}</div>
            <div className="mt-1 text-[11px] font-extrabold" style={{ color: c as string }}>{d}</div>
          </Card>
        ))}
      </div>

      <Card className="p-4 md:p-5" hover={false}>
        <div className="mb-3 flex items-center justify-between">
          <span className="label-caps !text-white/60">Congestion heat · live network</span>
          <Pill tone="orange"><span className="h-1.5 w-1.5 rounded-full bg-[#ff8a2b]" /> 3 hotspots</Pill>
        </div>
        <VadodaraMap cameras={CAMERAS} showRoute={false} height={340} />
      </Card>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Card className="p-5" hover={false}>
          <div className="flex items-center justify-between"><span className="label-caps">Vehicles / hour</span><span className="font-mono text-[12px] font-bold text-[#d3ff7d]">▲ 8.2%</span></div>
          <div className="mt-1 text-[26px] font-black"><CountUp value={12482} /></div>
          <div className="mt-3"><AreaChart data={HOURLY_FLOW} labels={HOURS} /></div>
        </Card>
        <Card className="p-5" hover={false}>
          <div className="flex items-center justify-between"><span className="label-caps">Average speed</span><span className="font-mono text-[12px] font-bold text-[#8fc6ff]">34 km/h</span></div>
          <div className="mt-1 text-[26px] font-black">34 <span className="text-[13px] text-white/40">km/h</span></div>
          <div className="mt-3"><AreaChart data={SPEED_SERIES} color="#4ea8ff" labels={HOURS} /></div>
        </Card>
        <Card className="p-5" hover={false}>
          <div className="flex items-center justify-between"><span className="label-caps">Congestion</span><span className="font-mono text-[12px] font-bold text-[#ffd97a]">peak 62%</span></div>
          <div className="mt-1 text-[26px] font-black">18<span className="text-[13px] text-white/40">% city avg</span></div>
          <div className="mt-3"><BarChart data={CONGESTION_SERIES} labels={HOURS} /></div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        <Card className="p-5 xl:col-span-8" hover={false}>
          <div className="label-caps mb-4">Top corridors</div>
          {TOP_CORRIDORS.map((c, i) => (
            <div key={i} className="mb-3.5 last:mb-0">
              <div className="mb-1.5 flex items-center justify-between text-[12px]">
                <span className="font-extrabold text-white">{c.route}</span>
                <span className="font-mono font-bold text-white/40">{c.volume} veh · {c.speed}</span>
              </div>
              <Progress value={c.load} color={c.load > 75 ? "#ff8a2b" : c.load > 55 ? "#b8ff2e" : "#4ea8ff"} />
            </div>
          ))}
        </Card>
        <Card className="flex items-center justify-around p-5 xl:col-span-4" hover={false}>
          <GaugeChart value={68} label="Peak load" sub="18:00 – 19:00" color="#ffc93c" />
          <GaugeChart value={82} label="Flow health" sub="network score" />
        </Card>
      </div>
    </div>
  );
}

/* ============ ALERTS ============ */
export function AlertsPage({ onInvestigate }: { onInvestigate: (p: string) => void }) {
  const [risk, setRisk] = useState("all");
  const [criticalOnly, setCriticalOnly] = useState(false);
  const [q, setQ] = useState("");
  const list = ALERTS.filter((a) => (risk === "all" || a.risk === risk) && (!criticalOnly || a.risk === "critical") && (a.plate.includes(q.toUpperCase()) || a.location.toLowerCase().includes(q.toLowerCase()) || a.trigger.toLowerCase().includes(q.toLowerCase())));

  return (
    <div className="space-y-4 pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-[22px] font-extrabold tracking-tight"><Bell className="h-5 w-5 text-[#ff6b7a]" /> Alert Command</h2>
          <p className="text-[12px] font-semibold text-white/40">{list.length} alerts match current filters · AI triage active</p>
        </div>
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 rounded-xl border border-white/[.08] bg-white/[.03] px-3.5 py-2.5">
            <Search className="h-4 w-4 text-white/35" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filter alerts…" className="w-36 bg-transparent text-[12px] font-bold text-white placeholder:text-white/30 focus:outline-none" />
          </div>
          <span className="hidden text-[11px] font-bold text-white/45 sm:block">Critical only</span>
          <Toggle on={criticalOnly} onChange={setCriticalOnly} accent="#ff3b4e" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {[["critical", "CRITICAL", "04", "#ff3b4e"], ["high", "HIGH", "09", "#ff8a2b"], ["medium", "MEDIUM", "14", "#ffc93c"], ["low", "LOW", "31", "#4ea8ff"]].map(([r, l, v, c]) => (
          <button key={r} onClick={() => setRisk(risk === r ? "all" : r)}
            className={cn("card flex items-center gap-3 p-4 text-left transition-all", risk === r && "ring-1")} style={risk === r ? { borderColor: `${c}66`, boxShadow: `0 0 24px -8px ${c}66` } : undefined}>
            <RiskDot risk={r} pulse={r === "critical"} />
            <span><span className="block text-[20px] font-black" style={{ color: c }}>{v}</span><span className="block text-[9px] font-extrabold tracking-[.18em] text-white/35">{l}</span></span>
          </button>
        ))}
      </div>

      <Card className="overflow-hidden p-0" hover={false}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left">
            <thead>
              <tr className="border-b border-white/[.06] bg-white/[.015] text-[10px] font-extrabold tracking-[.16em] text-white/30">
                <th className="px-5 py-3.5">VEHICLE</th><th className="py-3.5">TIME</th><th className="py-3.5">RISK</th><th className="py-3.5">LOCATION</th><th className="py-3.5">TRIGGER</th><th className="hidden py-3.5 xl:table-cell">CONFIDENCE</th><th className="px-5 py-3.5 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody>
              {list.map((a, i) => {
                const m = RISK_META[a.risk];
                return (
                  <motion.tr key={a.id} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.03 }}
                    onClick={() => onInvestigate(a.plate)} className="group cursor-pointer border-b border-white/[.04] transition-colors last:border-0 hover:bg-white/[.025]">
                    <td className="px-5 py-3.5"><span className="font-mono text-[13px] font-bold text-[#8fc6ff] group-hover:text-white">{a.plate}</span><div className="font-mono text-[10px] text-white/30">{a.id} · {a.camera}</div></td>
                    <td className="py-3.5 font-mono text-[12px] font-bold text-white/60">{a.time}</td>
                    <td className="py-3.5"><span className={cn("flex items-center gap-1.5 text-[12px] font-extrabold", m.text)}><RiskDot risk={a.risk} pulse={a.risk === "critical"} />{m.label}</span></td>
                    <td className="py-3.5 text-[12px] font-bold text-white/60">{a.location}</td>
                    <td className="py-3.5 text-[12px] font-semibold text-white/50">{a.trigger}</td>
                    <td className="hidden py-3.5 xl:table-cell"><div className="flex items-center gap-2"><div className="w-20"><Progress value={a.confidence} color={a.confidence > 90 ? "#b8ff2e" : "#ffc93c"} h="h-1" /></div><span className="font-mono text-[11px] text-white/50">{a.confidence}%</span></div></td>
                    <td className="px-5 py-3.5 text-right"><Pill tone={a.risk === "critical" ? "red" : a.risk === "high" ? "orange" : a.risk === "medium" ? "yellow" : "blue"}>{m.action}</Pill></td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ============ REPORTS ============ */
export function ReportsPage() {
  const [generating, setGenerating] = useState<number | null>(null);
  return (
    <div className="space-y-4 pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-[22px] font-extrabold tracking-tight">Reports & Exports</h2>
          <p className="text-[12px] font-semibold text-white/40">Court-ready evidence packs · Smart City compliance formats</p>
        </div>
        <button className="btn-volt flex items-center gap-2 rounded-xl px-4 py-2.5 text-[12px]"><Download className="h-4 w-4" /> NEW REPORT</button>
      </div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {[
          ["Daily Traffic Summary", "City-wide flow, incidents & ANPR stats", "PDF · 12 pages", "Today 06:00"],
          ["Investigation Dossier", "GJ-05-XY-9999 · trajectory + evidence", "PDF · Sealed", "18:42"],
          ["Corridor Performance", "Top 12 corridors · weekly trends", "XLSX · Charts", "Yesterday"],
          ["ANPR Accuracy Audit", "Per-camera precision & re-reads", "PDF · 8 pages", "28 Sep"],
          ["Violation Challan Batch", "42 no-entry + signal violations", "E-CHALLAN", "28 Sep"],
          ["Network Health Log", "Uptime, FPS & maintenance events", "CSV · Raw", "27 Sep"],
        ].map(([t, d, f, ts], i) => (
          <Card key={i} delay={i % 3} className="p-5">
            <div className="flex items-start justify-between">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#b8ff2e]/10"><FileText className="h-5 w-5 text-[#b8ff2e]" /></span>
              <span className="rounded-lg bg-white/[.05] px-2.5 py-1 font-mono text-[10px] font-bold text-white/50">{f}</span>
            </div>
            <div className="mt-3 text-[15px] font-extrabold text-white">{t}</div>
            <div className="mt-0.5 text-[12px] font-semibold text-white/40">{d}</div>
            <div className="mt-4 flex items-center gap-2">
              <button onClick={() => { setGenerating(i); setTimeout(() => setGenerating(null), 1600); }} className="btn-ghost flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-[12px] font-extrabold">
                {generating === i ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/20 border-t-white" /> : <Download className="h-3.5 w-3.5" />}
                {generating === i ? "Preparing…" : "Download"}
              </button>
              <span className="text-[10px] font-bold text-white/30">{ts}</span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ============ SETTINGS ============ */
export function SettingsPage() {
  const [s, setS] = useState({ live: true, anpr: true, push: true, auto: false, night: true, share: false });
  const tg = (k: keyof typeof s) => setS((p) => ({ ...p, [k]: !p[k] }));
  return (
    <div className="space-y-4 pb-6">
      <div>
        <h2 className="text-[22px] font-extrabold tracking-tight">Command Settings</h2>
        <p className="text-[12px] font-semibold text-white/40">Detection thresholds · alert routing · operator preferences</p>
      </div>
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Card className="p-5" hover={false}>
          <div className="label-caps mb-4 flex items-center gap-2"><SlidersHorizontal className="h-3.5 w-3.5" /> Detection engine</div>
          {[
            ["Live trajectory stitching", "Fuse multi-camera sightings in real time", "live"],
            ["ANPR auto-verification", "Dual-pass OCR on low-confidence reads", "anpr"],
            ["Night-vision boost", "IR enhancement after 19:00", "night"],
            ["Auto-escalate critical", "Page duty officer on blacklist hits", "auto"],
          ].map(([t, d, k]: any) => (
            <div key={k} className="flex items-center gap-3 border-b border-white/[.05] py-3.5 last:border-0">
              <div className="flex-1"><div className="text-[13px] font-extrabold text-white">{t}</div><div className="text-[11px] font-semibold text-white/40">{d}</div></div>
              <Toggle on={(s as any)[k]} onChange={() => tg(k)} />
            </div>
          ))}
          <div className="mt-4 rounded-2xl bg-white/[.02] p-4">
            <div className="mb-2 flex justify-between text-[11px] font-extrabold"><span className="text-white/50">ANPR CONFIDENCE THRESHOLD</span><span className="text-[#d3ff7d]">85%</span></div>
            <input type="range" defaultValue={85} className="w-full accent-[#b8ff2e]" />
            <div className="mb-2 mt-3 flex justify-between text-[11px] font-extrabold"><span className="text-white/50">ANOMALY SENSITIVITY</span><span className="text-[#ffd97a]">High</span></div>
            <input type="range" defaultValue={78} className="w-full accent-[#ffc93c]" />
          </div>
        </Card>
        <div className="space-y-4">
          <Card className="p-5" hover={false}>
            <div className="label-caps mb-4 flex items-center gap-2"><Bell className="h-3.5 w-3.5" /> Notifications</div>
            {[["Push alerts to console", "Instant banner on new critical alerts", "push"], ["Smart City data share", "Anonymised flow feed to VMC", "share"]].map(([t, d, k]: any) => (
              <div key={k} className="flex items-center gap-3 border-b border-white/[.05] py-3.5 last:border-0">
                <div className="flex-1"><div className="text-[13px] font-extrabold text-white">{t}</div><div className="text-[11px] font-semibold text-white/40">{d}</div></div>
                <Toggle on={(s as any)[k]} onChange={() => tg(k)} />
              </div>
            ))}
          </Card>
          <Card className="p-5" hover={false}>
            <div className="label-caps mb-3 flex items-center gap-2"><ShieldAlert className="h-3.5 w-3.5" /> Operator</div>
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[#2c2c37] to-[#15151c] text-[15px] font-black text-[#b8ff2e] ring-1 ring-white/10">RP</div>
              <div><div className="text-[14px] font-extrabold text-white">Insp. R. Parmar</div><div className="text-[11px] font-bold text-white/40">Traffic Intelligence Unit · Level 3 clearance</div></div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <Stat label="Shift" value="Day" /><Stat label="Cases" value="12" /><Stat label="Solved" value="9" accent="#b8ff2e" />
            </div>
          </Card>
          <div className="flex items-center gap-2.5 rounded-2xl border border-[#b8ff2e]/20 bg-[#b8ff2e]/[.05] p-4">
            <CheckCircle2 className="h-5 w-5 shrink-0 text-[#b8ff2e]" />
            <p className="text-[12px] font-bold text-white/60">All configurations sync to the command cloud. <span className="text-[#d3ff7d]">Last sync 31s ago.</span></p>
            <Zap className="ml-auto h-4 w-4 shrink-0 text-white/25" />
          </div>
        </div>
      </div>
    </div>
  );
}

/* shared mini header stats strip for sub pages */
export function MiniStats({ onSelectCamera }: { onSelectCamera: (c: CamType) => void }) {
  return (
    <div className="mb-4 flex items-center gap-2 overflow-x-auto no-scrollbar">
      {[["Race Course", "CAM-RC-014", "medium"], ["Akota Bridge", "CAM-AK-009", "online"], ["Sayajigunj", "CAM-SY-003", "online"], ["Waghodia Rd", "CAM-WR-021", "degraded"]].map(([l, id, st]) => (
        <button key={id} onClick={() => { const c = CAMERAS.find((x) => x.id === id); c && onSelectCamera(c); }}
          className="flex shrink-0 items-center gap-2 rounded-xl border border-white/[.07] bg-white/[.02] px-3 py-2 text-[11px] font-extrabold text-white/60 transition hover:border-[#b8ff2e]/30 hover:text-white">
          <RiskDot risk={st as string} /><MapPin className="h-3 w-3" />{l}<span className="font-mono text-white/30">{id}</span>
        </button>
      ))}
      <span className="flex shrink-0 items-center gap-2 px-2 text-[11px] font-bold text-white/30"><Clock className="h-3 w-3" /> All times IST <Gauge className="ml-2 h-3 w-3" /> <AlertTriangle className="h-3 w-3" /></span>
    </div>
  );
}
