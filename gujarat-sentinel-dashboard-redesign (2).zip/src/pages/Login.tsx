import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, BadgeCheck, Landmark, Lock, User, Eye, EyeOff, ArrowRight, ArrowLeft, KeyRound, CheckCircle2, AlertCircle, Radio, ScanLine, Video } from "lucide-react";
import { Logo } from "../components/Sidebar";
import VadodaraMap from "../components/VadodaraMap";
import { CAMERAS, TRAJECTORY } from "../data/mock";
import { ROLES, type RoleConfig, type RoleKey } from "../data/roles";
import { cn } from "../utils/cn";

const ICONS: Record<RoleKey, any> = { police: Shield, rto: BadgeCheck, government: Landmark };
const DEMO_PASSWORD = "sentinel@2026";

export default function Login({ onLogin }: { onLogin: (role: RoleConfig) => void }) {
  const [role, setRole] = useState<RoleConfig>(ROLES[0]);
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [step, setStep] = useState<"creds" | "otp" | "auth">("creds");
  const [otp, setOtp] = useState<string[]>(Array(6).fill(""));
  const [error, setError] = useState("");
  const [authLine, setAuthLine] = useState(0);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const AUTH_LINES = ["Verifying credentials", "Validating role clearance", "Establishing secure session", "Loading command center"];

  useEffect(() => { setError(""); }, [id, pw, otp, role]);

  const submitCreds = (e: React.FormEvent) => {
    e.preventDefault();
    if (id.trim().length < 4) return setError(`Enter a valid ${role.idLabel}.`);
    if (pw.length < 6) return setError("Password must be at least 6 characters.");
    setStep("otp");
    setTimeout(() => otpRefs.current[0]?.focus(), 350);
  };

  const startAuth = () => {
    setStep("auth");
    setAuthLine(0);
    [0, 1, 2, 3].forEach((i) => setTimeout(() => setAuthLine(i), i * 420));
    setTimeout(() => onLogin(role), 1900);
  };

  const setDigit = (i: number, v: string) => {
    const d = v.replace(/\D/g, "").slice(-1);
    const next = [...otp];
    next[i] = d;
    setOtp(next);
    if (d && i < 5) otpRefs.current[i + 1]?.focus();
  };

  const onOtpKey = (i: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[i] && i > 0) otpRefs.current[i - 1]?.focus();
  };

  const onPaste = (e: React.ClipboardEvent) => {
    const t = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (!t) return;
    e.preventDefault();
    setOtp(Array.from({ length: 6 }, (_, i) => t[i] ?? ""));
    otpRefs.current[Math.min(t.length, 5)]?.focus();
  };

  const submitOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.join("").length < 6) return setError("Enter the 6-digit verification code.");
    startAuth();
  };

  const fillDemo = () => {
    setId(role.demoId);
    setPw(DEMO_PASSWORD);
    setShowPw(true);
  };

  return (
    <div className="relative grid min-h-screen bg-[#050507] text-white lg:grid-cols-[1.15fr_1fr]">
      {/* ================= LEFT — BRAND / MAP ================= */}
      <div className="relative hidden overflow-hidden border-r border-white/[.06] lg:block">
        <div className="absolute inset-0 opacity-70">
          <VadodaraMap cameras={CAMERAS} route={TRAJECTORY} height={1100} showLabels={false} />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-[#050507]/95 via-[#050507]/55 to-[#050507]/90" />
        <div className="absolute inset-0" style={{ background: "radial-gradient(60% 50% at 30% 20%, rgba(184,255,46,.09), transparent 70%)" }} />

        <div className="relative flex h-full min-h-screen flex-col justify-between p-10 xl:p-14">
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Logo />
          </motion.div>

          <div className="max-w-xl">
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.6 }}
              className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#b8ff2e]/25 bg-[#b8ff2e]/[.07] px-3.5 py-1.5">
              <span className="relative flex h-2 w-2"><span className="absolute h-full w-full animate-ping rounded-full bg-[#b8ff2e] opacity-70" /><span className="h-2 w-2 rounded-full bg-[#b8ff2e]" /></span>
              <span className="text-[11px] font-black tracking-[.16em] text-[#d3ff7d]">VADODARA NETWORK · LIVE</span>
            </motion.div>
            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18, duration: 0.7 }}
              className="text-[44px] font-black leading-[1.04] tracking-tight xl:text-[58px]">
              See the movement.<br /><span className="text-[#b8ff2e] text-glow-volt">Understand the city.</span>
            </motion.h1>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.35 }} className="mt-4 text-[15px] font-semibold text-white/50">
              AI-Powered Vehicle Intelligence — ANPR, trajectory reconstruction and traffic analytics for Vadodara.
            </motion.p>

            <div className="mt-8 grid grid-cols-3 gap-3">
              {[
                [<Video key="v" className="h-4 w-4" />, "218 / 220", "Cameras online"],
                [<ScanLine key="s" className="h-4 w-4" />, "94.7%", "ANPR accuracy"],
                [<Radio key="r" className="h-4 w-4" />, "12,482", "Reads / hour"],
              ].map(([icon, v, l]: any, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 + i * 0.08 }}
                  className="rounded-2xl border border-white/10 bg-[#0a0a0e]/70 p-4 backdrop-blur-xl">
                  <span className="text-[#b8ff2e]">{icon}</span>
                  <div className="mt-2 text-[20px] font-black tabular-nums">{v}</div>
                  <div className="text-[10px] font-extrabold tracking-[.14em] text-white/35">{l.toUpperCase()}</div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] font-bold text-white/30">
            <span className="flex items-center gap-2"><Lock className="h-3.5 w-3.5" /> Authorised personnel only · All access is logged & audited</span>
            <span className="font-mono">v2026.9 · DEMO BUILD</span>
          </div>
        </div>

        {/* floating tracked plate */}
        <motion.div initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.9 }}
          className="absolute right-10 top-28 hidden w-60 rounded-2xl border border-[#b8ff2e]/20 bg-[#0a0a0e]/85 p-3.5 shadow-2xl backdrop-blur-xl xl:block">
          <div className="flex items-center justify-between">
            <span className="plate !text-[11px]">GJ-06-CD-5678</span>
            <span className="text-[9px] font-black tracking-widest text-[#d3ff7d]">TRACKING</span>
          </div>
          <div className="mt-2.5 text-[11px] font-bold text-white/50">Race Course Circle · 42 km/h</div>
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10"><motion.div initial={{ width: 0 }} animate={{ width: "72%" }} transition={{ delay: 1.2, duration: 1.4 }} className="h-full rounded-full bg-[#b8ff2e]" /></div>
        </motion.div>
      </div>

      {/* ================= RIGHT — FORM ================= */}
      <div className="relative flex items-center justify-center px-5 py-10 sm:px-10">
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(50% 40% at 70% 10%, rgba(184,255,46,.06), transparent 70%)" }} />
        <div className="map-grid pointer-events-none absolute inset-0 opacity-30 lg:opacity-0" />

        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }} className="relative w-full max-w-[460px]">
          <div className="mb-7 lg:hidden"><Logo /></div>

          <div className="mb-6">
            <h2 className="text-[28px] font-black tracking-tight">Secure <span className="text-[#b8ff2e]">Sign In</span></h2>
            <p className="mt-1 text-[13px] font-semibold text-white/40">Select your department and authenticate to access the command center.</p>
          </div>

          <div className="card p-5 sm:p-6">
            <AnimatePresence mode="wait">
              {/* ---------- STEP 1 ---------- */}
              {step === "creds" && (
                <motion.form key="creds" onSubmit={submitCreds} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.25 }}>
                  <div className="label-caps mb-2.5">Department</div>
                  <div className="grid grid-cols-3 gap-2">
                    {ROLES.map((r) => {
                      const Icon = ICONS[r.key];
                      const active = role.key === r.key;
                      return (
                        <button type="button" key={r.key} onClick={() => setRole(r)}
                          className={cn("relative flex flex-col items-center gap-2 rounded-2xl border px-2 py-3.5 transition-all duration-200",
                            active ? "border-[#b8ff2e]/45 bg-[#b8ff2e]/[.07]" : "border-white/[.08] bg-white/[.02] hover:border-white/20 hover:bg-white/[.04]")}>
                          {active && <motion.span layoutId="role-glow" className="absolute inset-0 rounded-2xl shadow-[0_0_30px_-8px_rgba(184,255,46,.5)]" />}
                          <span className={cn("relative flex h-10 w-10 items-center justify-center rounded-xl transition-colors", active ? "bg-[#b8ff2e] text-black" : "bg-white/[.05] text-white/60")}>
                            <Icon className="h-5 w-5" />
                          </span>
                          <span className={cn("relative text-[12px] font-extrabold", active ? "text-white" : "text-white/55")}>{r.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  <AnimatePresence mode="wait">
                    <motion.div key={role.key} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}
                      className="mt-3 rounded-2xl border border-white/[.06] bg-white/[.02] p-3.5">
                      <div className="text-[13px] font-extrabold text-white">{role.full}</div>
                      <div className="mt-0.5 text-[11.5px] font-semibold leading-relaxed text-white/45">{role.blurb}</div>
                      <div className="mt-2.5 flex flex-wrap gap-1.5">
                        {role.scope.map((s) => (
                          <span key={s} className="rounded-md bg-white/[.05] px-2 py-1 text-[10px] font-bold text-white/55">{s}</span>
                        ))}
                      </div>
                    </motion.div>
                  </AnimatePresence>

                  <div className="mt-5 space-y-3.5">
                    <div>
                      <label className="label-caps mb-1.5 block" htmlFor="uid">{role.idLabel}</label>
                      <div className="group flex items-center gap-2.5 rounded-xl border border-white/[.09] bg-black/40 px-3.5 py-3 transition-all focus-within:border-[#b8ff2e]/45 focus-within:shadow-[0_0_28px_-8px_rgba(184,255,46,.4)]">
                        <User className="h-4 w-4 shrink-0 text-white/30 group-focus-within:text-[#b8ff2e]" />
                        <input id="uid" value={id} onChange={(e) => setId(e.target.value.toUpperCase())} placeholder={role.idPlaceholder} autoComplete="username"
                          className="w-full bg-transparent font-mono text-[14px] font-bold tracking-wide text-white placeholder:font-sans placeholder:font-semibold placeholder:tracking-normal placeholder:text-white/25 focus:outline-none" />
                      </div>
                    </div>
                    <div>
                      <div className="mb-1.5 flex items-center justify-between">
                        <label className="label-caps" htmlFor="pw">Password</label>
                        <button type="button" className="text-[11px] font-bold text-white/35 transition hover:text-[#d3ff7d]">Forgot password?</button>
                      </div>
                      <div className="group flex items-center gap-2.5 rounded-xl border border-white/[.09] bg-black/40 px-3.5 py-3 transition-all focus-within:border-[#b8ff2e]/45 focus-within:shadow-[0_0_28px_-8px_rgba(184,255,46,.4)]">
                        <Lock className="h-4 w-4 shrink-0 text-white/30 group-focus-within:text-[#b8ff2e]" />
                        <input id="pw" type={showPw ? "text" : "password"} value={pw} onChange={(e) => setPw(e.target.value)} placeholder="••••••••••" autoComplete="current-password"
                          className="w-full bg-transparent text-[14px] font-semibold text-white placeholder:text-white/25 focus:outline-none" />
                        <button type="button" onClick={() => setShowPw(!showPw)} className="text-white/35 transition hover:text-white" aria-label="Toggle password visibility">
                          {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <button type="button" onClick={() => setRemember(!remember)} className="flex items-center gap-2 text-[12px] font-bold text-white/50 transition hover:text-white">
                      <span className={cn("flex h-[18px] w-[18px] items-center justify-center rounded-md border transition-all", remember ? "border-[#b8ff2e] bg-[#b8ff2e]" : "border-white/20")}>
                        {remember && <svg viewBox="0 0 12 12" className="h-3 w-3 text-black" fill="none" stroke="currentColor" strokeWidth={2.5}><path d="M2.5 6.5l2.3 2.3L9.5 3.5" /></svg>}
                      </span>
                      Keep me signed in
                    </button>
                    <button type="button" onClick={fillDemo} className="text-[11px] font-extrabold text-[#d3ff7d] underline-offset-4 transition hover:underline">Use demo credentials</button>
                  </div>

                  <AnimatePresence>
                    {error && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                        <div className="mt-4 flex items-center gap-2 rounded-xl border border-[#ff3b4e]/30 bg-[#ff3b4e]/[.07] px-3.5 py-2.5 text-[12px] font-bold text-[#ff8a95]"><AlertCircle className="h-4 w-4 shrink-0" />{error}</div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button type="submit" className="btn-volt mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-3.5 text-[13px]">
                    CONTINUE <ArrowRight className="h-4 w-4" />
                  </button>
                </motion.form>
              )}

              {/* ---------- STEP 2 — OTP ---------- */}
              {step === "otp" && (
                <motion.form key="otp" onSubmit={submitOtp} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 16 }} transition={{ duration: 0.25 }}>
                  <button type="button" onClick={() => { setStep("creds"); setOtp(Array(6).fill("")); }} className="mb-4 flex items-center gap-1.5 text-[12px] font-bold text-white/40 transition hover:text-white"><ArrowLeft className="h-3.5 w-3.5" /> Back</button>
                  <div className="flex items-center gap-3">
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#b8ff2e]/10 text-[#b8ff2e]"><KeyRound className="h-6 w-6" /></span>
                    <div>
                      <div className="text-[17px] font-black">Two-factor verification</div>
                      <div className="text-[12px] font-semibold text-white/40">Code sent to registered device of <span className="font-mono text-white/70">{id || role.demoId}</span></div>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-between gap-2" onPaste={onPaste}>
                    {otp.map((d, i) => (
                      <input key={i} ref={(el) => { otpRefs.current[i] = el; }} value={d} inputMode="numeric" maxLength={1}
                        onChange={(e) => setDigit(i, e.target.value)} onKeyDown={(e) => onOtpKey(i, e)}
                        className={cn("h-14 w-full min-w-0 rounded-xl border bg-black/40 text-center font-mono text-[22px] font-black text-white transition-all focus:outline-none",
                          d ? "border-[#b8ff2e]/50 shadow-[0_0_20px_-6px_rgba(184,255,46,.5)]" : "border-white/10 focus:border-[#b8ff2e]/45")} />
                    ))}
                  </div>

                  <div className="mt-3 flex items-center justify-between text-[11px] font-bold">
                    <span className="text-white/35">Demo mode: enter any 6-digit code</span>
                    <button type="button" onClick={() => { setOtp("482913".split("")); }} className="text-[#d3ff7d] transition hover:underline">Autofill</button>
                  </div>

                  <AnimatePresence>
                    {error && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                        <div className="mt-4 flex items-center gap-2 rounded-xl border border-[#ff3b4e]/30 bg-[#ff3b4e]/[.07] px-3.5 py-2.5 text-[12px] font-bold text-[#ff8a95]"><AlertCircle className="h-4 w-4 shrink-0" />{error}</div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button type="submit" className="btn-volt mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-3.5 text-[13px]">
                    VERIFY & ENTER COMMAND CENTER <ArrowRight className="h-4 w-4" />
                  </button>
                </motion.form>
              )}

              {/* ---------- STEP 3 — AUTH ---------- */}
              {step === "auth" && (
                <motion.div key="auth" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-4">
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#b8ff2e] shadow-[0_0_40px_-6px_rgba(184,255,46,.6)]">
                    {(() => { const Icon = ICONS[role.key]; return <Icon className="h-8 w-8 text-black" />; })()}
                  </div>
                  <div className="mt-4 text-center">
                    <div className="text-[18px] font-black">Welcome, {role.profile.name}</div>
                    <div className="text-[12px] font-semibold text-white/40">{role.profile.unit}</div>
                  </div>
                  <div className="mt-5 h-1 overflow-hidden rounded-full bg-white/10"><motion.div initial={{ width: "5%" }} animate={{ width: "100%" }} transition={{ duration: 1.8, ease: "easeInOut" }} className="h-full rounded-full bg-[#b8ff2e] shadow-[0_0_12px_#b8ff2e]" /></div>
                  <div className="mt-4 space-y-2">
                    {AUTH_LINES.map((l, i) => (
                      <div key={l} className={cn("flex items-center gap-2.5 text-[12px] font-bold transition-all duration-300", i <= authLine ? "text-white/80" : "text-white/20")}>
                        {i < authLine ? <CheckCircle2 className="h-4 w-4 text-[#b8ff2e]" /> : i === authLine ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/20 border-t-[#b8ff2e]" /> : <span className="h-4 w-4 rounded-full border border-white/10" />}
                        {l}
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="mt-5 flex items-start gap-2.5 rounded-2xl border border-white/[.06] bg-white/[.015] p-3.5 text-[11px] font-semibold leading-relaxed text-white/35">
            <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#b8ff2e]" />
            <span>This is a demonstration build. Authentication is simulated locally — no credentials are transmitted or stored. Demo password: <span className="font-mono text-white/60">{DEMO_PASSWORD}</span></span>
          </div>
          <div className="mt-4 text-center text-[11px] font-bold text-white/25">© 2026 Gujarat Sentinel · AI-Powered Vehicle Intelligence</div>
        </motion.div>
      </div>
    </div>
  );
}
