import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, MapPin, Clock, Gauge, AlertTriangle, ChevronRight, ShieldAlert, Camera, ScanLine, Play, FileCheck } from "lucide-react";
import { FOCUS_VEHICLE, TRAJECTORY, RISK_META, type Camera as CamType } from "../data/mock";
import { RiskDot, Progress } from "./ui";
import VadodaraMap from "./VadodaraMap";
import { CAMERAS } from "../data/mock";

export function CameraPanel({ camera, onClose, onInvestigate }: { camera: CamType | null; onClose: () => void; onInvestigate: (plate: string) => void }) {
  return (
    <AnimatePresence>
      {camera && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm" />
          <motion.aside
            initial={{ x: 420, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 420, opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
            className="fixed right-0 top-0 z-[61] flex h-full w-full max-w-[400px] flex-col overflow-y-auto border-l border-white/10 bg-[#0a0a0e] shadow-2xl"
          >
            <div className="relative h-52 shrink-0 overflow-hidden">
              <img src="/images/anpr-feed.png" alt="camera feed" className="h-full w-full object-cover opacity-80" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0e] via-transparent to-black/40" />
              <div className="absolute left-4 top-4 flex items-center gap-2">
                <span className="rounded-lg bg-black/70 px-2.5 py-1 font-mono text-[11px] font-bold text-white backdrop-blur">{camera.id}</span>
                <span className="flex items-center gap-1.5 rounded-lg bg-black/70 px-2.5 py-1 text-[10px] font-black tracking-widest text-[#b8ff2e] backdrop-blur">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#b8ff2e]" /> LIVE
                </span>
              </div>
              <button onClick={onClose} className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur transition hover:bg-black/90"><X className="h-4 w-4" /></button>
              <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                <div>
                  <div className="text-[15px] font-extrabold text-white">{camera.name}</div>
                  <div className="text-[11px] font-bold text-white/50">{camera.area} · Vadodara</div>
                </div>
                <span className="rounded-lg bg-[#b8ff2e]/15 px-2 py-1 text-[10px] font-black tracking-widest text-[#d3ff7d] ring-1 ring-[#b8ff2e]/30">DEMO FEED</span>
              </div>
              {/* scanline */}
              <div className="scanline absolute inset-x-4 h-px bg-[#b8ff2e]/60 shadow-[0_0_12px_#b8ff2e]" />
            </div>

            <div className="space-y-4 p-5">
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { l: "STATUS", v: camera.status.toUpperCase(), c: camera.status === "online" ? "#b8ff2e" : camera.status === "degraded" ? "#ffc93c" : "#ff3b4e" },
                  { l: "FPS", v: `${camera.fps}`, c: "#fff" },
                  { l: "ANPR", v: `${camera.anpr.toFixed(1)}%`, c: "#fff" },
                ].map((s) => (
                  <div key={s.l} className="rounded-xl border border-white/[.07] bg-white/[.02] p-3 text-center">
                    <div className="text-[9px] font-extrabold tracking-[.18em] text-white/35">{s.l}</div>
                    <div className="mt-1 text-[15px] font-extrabold" style={{ color: s.c }}>{s.v}</div>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl border border-white/[.07] bg-white/[.02] p-4">
                <div className="flex items-center gap-2 text-[10px] font-extrabold tracking-[.18em] text-white/35"><ScanLine className="h-3.5 w-3.5" /> LATEST DETECTION</div>
                {camera.plate ? (
                  <div className="mt-3 flex items-center justify-between">
                    <span className="plate text-[13px]">{camera.plate}</span>
                    <span className="font-mono text-[11px] text-white/40">{camera.lastDetection}</span>
                  </div>
                ) : <div className="mt-3 text-[12px] font-bold text-white/40">No recent detections</div>}
                {camera.plate && (
                  <button onClick={() => onInvestigate(camera.plate!)} className="btn-volt mt-3 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-[12px]">
                    OPEN INVESTIGATION <ChevronRight className="h-4 w-4" />
                  </button>
                )}
              </div>

              <div className="rounded-2xl border border-white/[.07] bg-white/[.02] p-4">
                <div className="text-[10px] font-extrabold tracking-[.18em] text-white/35">SIGNAL HEALTH · 24H</div>
                <div className="mt-3 space-y-2.5">
                  {[["Stream stability", 96, "#b8ff2e"], ["ANPR accuracy", camera.anpr || 62, "#b8ff2e"], ["Night vision", 88, "#4ea8ff"]].map(([l, v, c]: any) => (
                    <div key={l}>
                      <div className="mb-1 flex justify-between text-[11px] font-bold text-white/50"><span>{l}</span><span className="text-white">{v}%</span></div>
                      <Progress value={v} color={c} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

const TABS = ["Overview", "Trajectory", "Evidence", "Alerts", "Timeline"];

export default function InvestigationDrawer({ plate, onClose }: { plate: string | null; onClose: () => void }) {
  const [tab, setTab] = useState("Overview");
  const v = { ...FOCUS_VEHICLE, plate: plate ?? FOCUS_VEHICLE.plate };
  const meta = RISK_META[v.risk];

  return (
    <AnimatePresence>
      {plate && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm" />
          <motion.aside
            initial={{ x: 560, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 560, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 34 }}
            className="fixed right-0 top-0 z-[61] flex h-full w-full max-w-[520px] flex-col border-l border-white/10 bg-[#0a0a0e] shadow-2xl"
          >
            {/* header */}
            <div className="border-b border-white/[.07] p-5 pb-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 text-[10px] font-extrabold tracking-[.2em] text-white/35"><ShieldAlert className="h-3.5 w-3.5 text-[#ffc93c]" /> VEHICLE INVESTIGATION</div>
                  <div className="mt-2.5 flex flex-wrap items-center gap-3">
                    <span className="plate text-[15px]">{v.plate}</span>
                    <span className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-extrabold uppercase tracking-wider ${meta.bg} ${meta.border} ${meta.text}`}>
                      <RiskDot risk={v.risk} pulse /> {meta.label}
                    </span>
                  </div>
                </div>
                <button onClick={onClose} className="btn-ghost flex h-9 w-9 items-center justify-center rounded-xl"><X className="h-4 w-4" /></button>
              </div>
              <div className="mt-4 flex gap-1 overflow-x-auto rounded-xl bg-white/[.03] p-1 no-scrollbar">
                {TABS.map((t) => (
                  <button key={t} onClick={() => setTab(t)}
                    className={`relative shrink-0 rounded-lg px-3.5 py-2 text-[12px] font-extrabold transition-colors ${tab === t ? "text-black" : "text-white/45 hover:text-white"}`}>
                    {tab === t && <motion.span layoutId="inv-tab" className="absolute inset-0 rounded-lg bg-[#b8ff2e]" />}
                    <span className="relative">{t}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-5">
              {tab === "Overview" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-2.5">
                    {[
                      ["Vehicle Type", v.type.split("·")[0].trim()], ["First Seen", v.firstSeen], ["Last Seen", v.lastSeen.slice(0, 5)],
                      ["Detections", `${v.detections}`], ["ANPR Conf.", `${v.anprConfidence}%`], ["Risk Score", "64 / 100"],
                    ].map(([l, val]) => (
                      <div key={l} className="rounded-xl border border-white/[.07] bg-white/[.02] p-3">
                        <div className="text-[9px] font-extrabold tracking-[.16em] text-white/35">{l.toUpperCase()}</div>
                        <div className="mt-1 truncate text-[13px] font-extrabold text-white">{val}</div>
                      </div>
                    ))}
                  </div>

                  <div>
                    <div className="label-caps mb-2">Live trajectory map</div>
                    <VadodaraMap cameras={CAMERAS} route={TRAJECTORY} height={240} showLabels={false} />
                  </div>

                  <div className="rounded-2xl border border-[#ff8a2b]/25 bg-[#ff8a2b]/[.05] p-4">
                    <div className="flex items-center gap-2 text-[12px] font-extrabold text-[#ffb37a]"><AlertTriangle className="h-4 w-4" /> ROUTE ANOMALY DETECTED</div>
                    <div className="mt-3 grid grid-cols-3 gap-3 text-center">
                      {[["Expected", "12–18 min"], ["Observed", "2 min"], ["Confidence", "91%"]].map(([l, val]) => (
                        <div key={l} className="rounded-xl bg-black/30 p-2.5">
                          <div className="text-[9px] font-extrabold tracking-widest text-white/35">{l.toUpperCase()}</div>
                          <div className="mt-0.5 text-[14px] font-extrabold text-white">{val}</div>
                        </div>
                      ))}
                    </div>
                    <p className="mt-3 text-[12px] font-semibold leading-relaxed text-white/55">
                      Vehicle covered Alkapuri → Sayajigunj 6.4× faster than corridor baseline. Possible plate cloning or ANPR misread — verification recommended.
                    </p>
                  </div>

                  <div>
                    <div className="label-caps mb-2">Detection timeline</div>
                    <div className="space-y-0">
                      {TRAJECTORY.slice(0, 4).map((s, i) => (
                        <div key={i} className="relative flex gap-3.5 pb-5 last:pb-0">
                          {i < 3 && <span className="absolute left-[5px] top-4 h-full w-px bg-gradient-to-b from-[#b8ff2e]/60 to-[#b8ff2e]/10" />}
                          <span className="mt-1.5 h-[11px] w-[11px] shrink-0 rounded-full border-2 border-[#b8ff2e] bg-[#0a0a0e] shadow-[0_0_10px_#b8ff2e]" />
                          <div className="flex-1 rounded-xl border border-white/[.06] bg-white/[.02] px-3.5 py-2.5">
                            <div className="flex items-center justify-between">
                              <span className="font-mono text-[12px] font-bold text-[#d3ff7d]">{s.time}</span>
                              <span className="text-[10px] font-bold text-white/35">{s.confidence}% conf</span>
                            </div>
                            <div className="mt-0.5 text-[13px] font-extrabold text-white">{s.location}</div>
                            <div className="text-[11px] font-semibold text-white/40">{s.camera}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {tab === "Trajectory" && (
                <div className="space-y-4">
                  <VadodaraMap cameras={CAMERAS} route={TRAJECTORY} height={300} showLabels={false} />
                  {TRAJECTORY.map((s, i) => (
                    <div key={i} className="flex items-center gap-3 rounded-xl border border-white/[.06] bg-white/[.02] p-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#b8ff2e]/10 font-mono text-[11px] font-bold text-[#d3ff7d]">{String(i + 1).padStart(2, "0")}</div>
                      <div className="flex-1"><div className="text-[13px] font-extrabold text-white">{s.location}</div><div className="text-[11px] font-semibold text-white/40">{s.time} · {s.camera}</div></div>
                      <span className="font-mono text-[11px] font-bold text-white/50">{s.confidence}%</span>
                    </div>
                  ))}
                </div>
              )}

              {tab === "Evidence" && (
                <div className="space-y-3">
                  <div className="rounded-2xl border border-white/[.07] bg-white/[.02] p-4 text-center">
                    <Camera className="mx-auto h-6 w-6 text-white/25" />
                    <div className="mt-2 text-[13px] font-extrabold text-white">4 ANPR captures attached</div>
                    <div className="text-[11px] font-semibold text-white/40">Demo evidence locker · SHA-256 sealed</div>
                  </div>
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="overflow-hidden rounded-2xl border border-white/[.07]">
                      <div className="relative">
                        <img src="/images/anpr-feed.png" alt="evidence" className="h-36 w-full object-cover opacity-70" style={{ objectPosition: `center ${i * 25}%` }} />
                        <span className="absolute left-3 top-3 rounded-md bg-black/70 px-2 py-1 font-mono text-[10px] font-bold text-[#d3ff7d]">EVD-2026-{3100 + i}</span>
                        <button className="absolute inset-0 m-auto flex h-10 w-10 items-center justify-center rounded-full bg-[#b8ff2e] text-black shadow-lg"><Play className="h-4 w-4 fill-black" /></button>
                      </div>
                      <div className="flex items-center justify-between bg-white/[.02] px-4 py-2.5">
                        <span className="font-mono text-[11px] font-bold text-white/60">{TRAJECTORY[i]?.time} · {TRAJECTORY[i]?.camera}</span>
                        <span className="flex items-center gap-1 text-[11px] font-bold text-[#b8ff2e]"><FileCheck className="h-3.5 w-3.5" /> Verified</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {tab === "Alerts" && (
                <div className="space-y-2.5">
                  {[
                    ["Impossible Travel", "high", "Akota · 18:35 · 91.4%"],
                    ["Unusual Dwell · 42m", "medium", "Sayajigunj · 18:28 · 84.6%"],
                    ["First-time Corridor", "low", "OP Road · 17:58 · 76.4%"],
                  ].map(([t, r, s], i) => (
                    <div key={i} className="flex items-center gap-3 rounded-xl border border-white/[.06] bg-white/[.02] p-3.5">
                      <RiskDot risk={r} pulse />
                      <div className="flex-1"><div className="text-[13px] font-extrabold text-white">{t}</div><div className="text-[11px] font-semibold text-white/40">{s}</div></div>
                      <ChevronRight className="h-4 w-4 text-white/25" />
                    </div>
                  ))}
                </div>
              )}

              {tab === "Timeline" && (
                <div className="space-y-3">
                  {[
                    ["18:42", "Detected at Race Course Circle", "ANPR 98.4% · North-East bound"],
                    ["18:35", "Anomaly flagged: impossible travel", "AI engine · confidence 91%"],
                    ["17:35", "Detected at Waghodia Road", "ANPR 91.7% · degraded feed"],
                    ["17:26", "Detected at Akota Bridge", "ANPR 95.1%"],
                    ["17:10", "First seen at Alkapuri Circle", "ANPR 97.8% · track opened"],
                  ].map(([t, title, sub], i) => (
                    <div key={i} className="flex gap-3">
                      <div className="flex w-12 shrink-0 flex-col items-center">
                        <span className="font-mono text-[11px] font-bold text-[#d3ff7d]">{t}</span>
                        {i < 4 && <span className="mt-1 w-px flex-1 bg-white/10" />}
                      </div>
                      <div className="pb-4"><div className="text-[13px] font-extrabold text-white">{title}</div><div className="text-[11px] font-semibold text-white/40">{sub}</div></div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="border-t border-white/[.07] bg-[#0a0a0e] p-4">
              <div className="flex gap-2.5">
                <button className="btn-volt flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-[13px]">START INVESTIGATION <ChevronRight className="h-4 w-4" /></button>
                <button className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-3 text-[13px] font-bold"><MapPin className="h-4 w-4" /> Track</button>
                <button className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-3 text-[13px] font-bold"><Clock className="h-4 w-4" /><Gauge className="hidden h-4 w-4" /></button>
              </div>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
