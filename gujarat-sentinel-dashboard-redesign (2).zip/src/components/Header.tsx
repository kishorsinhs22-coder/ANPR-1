import { useEffect, useState } from "react";
import { Search, Bell, Menu, MapPin, ChevronDown, LogOut } from "lucide-react";
import type { RoleConfig } from "../data/roles";
import { motion, AnimatePresence } from "framer-motion";
import { RECENT_DETECTIONS } from "../data/mock";

export default function Header({ onMenu, onSearchPlate, query, setQuery, user, onLogout }: { onMenu: () => void; onSearchPlate: (plate: string) => void; query: string; setQuery: (q: string) => void; user: RoleConfig; onLogout: () => void }) {
  const [time, setTime] = useState(new Date());
  const [profileOpen, setProfileOpen] = useState(false);
  const p = user.profile;
  const [focused, setFocused] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const suggestions = RECENT_DETECTIONS.filter((d) => d.plate.toLowerCase().includes(query.toLowerCase())).slice(0, 5);

  return (
    <header className="sticky top-0 z-40 border-b border-white/[.06] bg-[#050507]/85 backdrop-blur-xl">
      <div className="flex items-center gap-3 px-4 py-3 md:px-6">
        <button onClick={onMenu} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-xl lg:hidden">
          <Menu className="h-5 w-5" />
        </button>

        <div className="min-w-0">
          <h1 className="truncate text-lg font-extrabold tracking-tight text-white md:text-[22px]">
            Good morning, <span className="text-[#b8ff2e]">{p.salutation}.</span>
          </h1>
          <p className="hidden items-center gap-1.5 text-[11px] font-bold tracking-[.14em] text-white/35 sm:flex">
            <MapPin className="h-3 w-3" /> VADODARA INTELLIGENT TRAFFIC NETWORK
          </p>
        </div>

        {/* global search */}
        <div className="relative mx-auto hidden w-full max-w-md md:block">
          <div className={`flex items-center gap-2 rounded-2xl border bg-white/[.03] px-4 py-2.5 transition-all ${focused ? "border-[#b8ff2e]/40 shadow-[0_0_30px_-8px_rgba(184,255,46,.35)]" : "border-white/[.08]"}`}>
            <Search className="h-4 w-4 shrink-0 text-white/35" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setTimeout(() => setFocused(false), 150)}
              onKeyDown={(e) => { if (e.key === "Enter" && query.trim()) onSearchPlate(query.trim().toUpperCase()); }}
              placeholder="Search vehicle, camera, location…"
              className="w-full bg-transparent text-[13px] font-semibold text-white placeholder:text-white/30 focus:outline-none"
            />
            <kbd className="hidden rounded-md border border-white/10 bg-white/[.04] px-1.5 py-0.5 font-mono text-[10px] text-white/30 lg:block">⌘K</kbd>
          </div>
          <AnimatePresence>
            {focused && (
              <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} transition={{ duration: 0.18 }}
                className="absolute inset-x-0 top-full z-50 mt-2 overflow-hidden rounded-2xl border border-white/10 bg-[#0b0b10]/98 shadow-2xl backdrop-blur-xl">
                <div className="px-4 pb-1 pt-3 text-[10px] font-extrabold tracking-[.18em] text-white/30">RECENT DETECTIONS</div>
                {suggestions.map((d) => (
                  <button key={d.plate + d.time} onMouseDown={() => onSearchPlate(d.plate)}
                    className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-white/[.04]">
                    <span className="plate !py-0.5 !text-[10px]">{d.plate}</span>
                    <span className="text-[11px] font-bold text-white/40">{d.cam}</span>
                    <span className="ml-auto font-mono text-[11px] text-white/40">{d.time}</span>
                  </button>
                ))}
                <div className="border-t border-white/[.06] p-2">
                  <div className="rounded-xl bg-[#b8ff2e]/[.06] px-3 py-2 text-[11px] font-bold text-[#d3ff7d]">Press Enter to run full vehicle intelligence search →</div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="ml-auto flex items-center gap-2.5 md:gap-3">
          <div className="hidden items-center gap-2 rounded-full border border-[#b8ff2e]/25 bg-[#b8ff2e]/[.07] px-3.5 py-1.5 sm:flex">
            <span className="relative flex h-2 w-2"><span className="absolute h-full w-full animate-ping rounded-full bg-[#b8ff2e] opacity-70" /><span className="h-2 w-2 rounded-full bg-[#b8ff2e]" /></span>
            <span className="text-[11px] font-black tracking-[.14em] text-[#d3ff7d]">LIVE</span>
          </div>
          <div className="hidden text-right leading-tight xl:block">
            <div className="font-mono text-[12px] font-bold text-white tabular-nums">{time.toLocaleTimeString("en-IN", { hour12: false })}</div>
            <div className="text-[10px] font-bold text-white/35">29 Sep 2026 · Vadodara</div>
          </div>
          <div className="relative">
            <button onClick={() => setNotifOpen(!notifOpen)} className="btn-ghost relative flex h-10 w-10 items-center justify-center rounded-xl">
              <Bell className="h-[18px] w-[18px]" />
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-[#ff3b4e] text-[10px] font-black text-white ring-2 ring-[#050507]">3</span>
            </button>
            <AnimatePresence>
              {notifOpen && (
                <motion.div initial={{ opacity: 0, y: 8, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: .98 }}
                  className="absolute right-0 top-full z-50 mt-2 w-80 overflow-hidden rounded-2xl border border-white/10 bg-[#0b0b10] shadow-2xl">
                  <div className="flex items-center justify-between px-4 py-3">
                    <span className="text-[12px] font-extrabold text-white">Notifications</span>
                    <span className="rounded-full bg-[#ff3b4e]/15 px-2 py-0.5 text-[10px] font-black text-[#ff6b7a]">3 NEW</span>
                  </div>
                  {[
                    { c: "#ff3b4e", t: "Blacklist match — GJ-05-XY-9999", s: "Race Course · CAM-RC-014 · 2m ago" },
                    { c: "#ff8a2b", t: "Impossible travel detected", s: "GJ-06-CD-5678 · Akota · 9m ago" },
                    { c: "#ffc93c", t: "CAM-WR-021 degraded to 12 FPS", s: "Waghodia Rd · 24m ago" },
                  ].map((n, i) => (
                    <div key={i} className="flex gap-3 border-t border-white/[.06] px-4 py-3">
                      <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: n.c, boxShadow: `0 0 8px ${n.c}` }} />
                      <div><div className="text-[12px] font-bold text-white">{n.t}</div><div className="text-[11px] font-semibold text-white/40">{n.s}</div></div>
                    </div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <div className="relative">
            <button onClick={() => setProfileOpen(!profileOpen)} className="flex items-center gap-2 rounded-xl border border-white/[.08] bg-white/[.03] py-1.5 pl-1.5 pr-2.5 transition-colors hover:bg-white/[.06]">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-[#33333f] to-[#17171d] text-[10px] font-black text-[#b8ff2e] ring-1 ring-white/10">{p.initials}</span>
              <span className="hidden rounded-md bg-[#b8ff2e]/10 px-1.5 py-0.5 text-[9px] font-black tracking-widest text-[#d3ff7d] md:block">{p.badge}</span>
              <ChevronDown className="h-3.5 w-3.5 text-white/40" />
            </button>
            <AnimatePresence>
              {profileOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} />
                  <motion.div initial={{ opacity: 0, y: 8, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: .98 }} transition={{ duration: 0.16 }}
                    className="absolute right-0 top-full z-50 mt-2 w-72 overflow-hidden rounded-2xl border border-white/10 bg-[#0b0b10] shadow-2xl">
                    <div className="flex items-center gap-3 p-4">
                      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-[#33333f] to-[#17171d] text-[13px] font-black text-[#b8ff2e] ring-1 ring-white/10">{p.initials}</span>
                      <div className="min-w-0 leading-tight">
                        <div className="truncate text-[13px] font-extrabold text-white">{p.name}</div>
                        <div className="truncate text-[11px] font-semibold text-white/40">{p.unit}</div>
                      </div>
                    </div>
                    <div className="border-t border-white/[.06] px-4 py-3">
                      <div className="flex items-center justify-between text-[10px] font-extrabold tracking-[.16em] text-white/30"><span>ROLE</span><span className="text-[#d3ff7d]">{user.label.toUpperCase()} · {user.full.toUpperCase()}</span></div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {user.scope.map((s) => <span key={s} className="rounded-md bg-white/[.05] px-2 py-1 text-[10px] font-bold text-white/55">{s}</span>)}
                      </div>
                    </div>
                    <button onClick={onLogout} className="flex w-full items-center gap-2.5 border-t border-white/[.06] px-4 py-3 text-[12px] font-extrabold text-[#ff8a95] transition hover:bg-[#ff3b4e]/[.07]">
                      <LogOut className="h-4 w-4" /> Sign out
                    </button>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
      {/* mobile search */}
      <div className="px-4 pb-3 md:hidden">
        <div className="flex items-center gap-2 rounded-xl border border-white/[.08] bg-white/[.03] px-3.5 py-2.5">
          <Search className="h-4 w-4 text-white/35" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && query.trim()) onSearchPlate(query.trim().toUpperCase()); }}
            placeholder="Search vehicle, camera, location…" className="w-full bg-transparent text-[13px] font-semibold text-white placeholder:text-white/30 focus:outline-none" />
        </div>
      </div>
    </header>
  );
}
