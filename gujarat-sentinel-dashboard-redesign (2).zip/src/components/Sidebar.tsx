import { LayoutDashboard, Video, Search, Route, BarChart3, Bell, ScanLine, Network, FileText, Settings, ShieldCheck, LogOut } from "lucide-react";
import type { RoleConfig } from "../data/roles";
import { motion } from "framer-motion";
import { cn } from "../utils/cn";

const ICONS: Record<string, any> = {
  dashboard: LayoutDashboard,
  cameras: Video,
  search: Search,
  trajectory: Route,
  analytics: BarChart3,
  alerts: Bell,
  anpr: ScanLine,
  network: Network,
  reports: FileText,
  settings: Settings,
};

export const NAV = [
  { id: "dashboard", label: "Dashboard" },
  { id: "cameras", label: "Live Cameras" },
  { id: "search", label: "Vehicle Search" },
  { id: "trajectory", label: "Trajectory" },
  { id: "analytics", label: "Traffic Analytics" },
  { id: "alerts", label: "Alerts", badge: 10 },
  { id: "anpr", label: "ANPR" },
  { id: "network", label: "Camera Network" },
  { id: "reports", label: "Reports" },
  { id: "settings", label: "Settings" },
];

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#b8ff2e] shadow-[0_0_24px_-4px_rgba(184,255,46,.6)]">
        <svg viewBox="0 0 24 24" className="h-5 w-5 text-black" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2l8 3.5v5.2c0 5-3.4 8.6-8 10.3-4.6-1.7-8-5.3-8-10.3V5.5L12 2z" />
          <path d="M8.5 12h2l1.2-2.4 1.6 4.4 1.2-2h1" />
        </svg>
        <span className="absolute -right-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#050507] text-[8px] font-black text-[#b8ff2e] ring-1 ring-[#b8ff2e]/40">◉</span>
      </div>
      {!compact && (
        <div className="leading-none">
          <div className="text-[13px] font-extrabold tracking-[.08em] text-white">GUJARAT <span className="text-[#b8ff2e]">SENTINEL</span></div>
          <div className="mt-1 text-[9px] font-semibold tracking-[.22em] text-white/35">TRAFFIC INTELLIGENCE</div>
        </div>
      )}
    </div>
  );
}

export default function Sidebar({ active, onNav, collapsed, user, onLogout }: { active: string; onNav: (id: string) => void; collapsed?: boolean; user: RoleConfig; onLogout: () => void }) {
  const p = user.profile;
  return (
    <aside className={cn("hidden flex-col lg:flex", collapsed ? "w-[76px]" : "w-[228px]") + " shrink-0 transition-all duration-300"}>
      <div className="sticky top-0 flex h-screen flex-col px-3 py-5">
        <div className={cn("px-2", collapsed && "flex justify-center px-0")}>
          <Logo compact={collapsed} />
        </div>

        <nav className="mt-7 flex-1 space-y-1 overflow-y-auto no-scrollbar">
          {NAV.map((item) => {
            const Icon = ICONS[item.id];
            const isActive = active === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNav(item.id)}
                title={collapsed ? item.label : undefined}
                className={cn(
                  "group relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-bold transition-all duration-200",
                  isActive ? "bg-[#b8ff2e] text-[#0b0d06] shadow-[0_10px_28px_-10px_rgba(184,255,46,.55)]" : "text-white/45 hover:bg-white/[.05] hover:text-white",
                  collapsed && "justify-center px-0"
                )}
              >
                <Icon className={cn("h-[18px] w-[18px] shrink-0", isActive ? "text-black" : "text-white/40 group-hover:text-white/80")} strokeWidth={2} />
                {!collapsed && <span className="truncate">{item.label}</span>}
                {!collapsed && (item as any).badge && (
                  <span className={cn("ml-auto flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-black", isActive ? "bg-black/20 text-black" : "bg-[#ff3b4e]/15 text-[#ff6b7a] ring-1 ring-[#ff3b4e]/30")}>
                    {(item as any).badge}
                  </span>
                )}
                {collapsed && (item as any).badge && (
                  <span className="absolute right-2 top-2 flex h-4 w-4 items-center justify-center rounded-full bg-[#ff3b4e] text-[9px] font-black text-white">{(item as any).badge}</span>
                )}
                {isActive && !collapsed && (
                  <motion.span layoutId="nav-glow" className="absolute inset-0 -z-10 rounded-xl bg-[#b8ff2e]/20 blur-xl" />
                )}
              </button>
            );
          })}
        </nav>

        {!collapsed ? (
          <div className="mt-4 space-y-3">
            <div className="rounded-2xl border border-white/[.07] bg-white/[.02] p-3.5">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-[#b8ff2e]" />
                <span className="text-[10px] font-extrabold tracking-[.16em] text-white/40">SYSTEM STATUS</span>
              </div>
              <div className="mt-2.5 flex items-center gap-2">
                <span className="relative flex h-2 w-2"><span className="absolute h-full w-full animate-ping rounded-full bg-[#b8ff2e] opacity-60" /><span className="h-2 w-2 rounded-full bg-[#b8ff2e]" /></span>
                <span className="text-[11px] font-extrabold tracking-wide text-[#d3ff7d]">ALL SYSTEMS OPERATIONAL</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-[10px] font-bold text-white/30">
                <span>Uptime 99.98%</span><span className="text-white/50">31 ms</span>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-2xl border border-white/[.07] bg-white/[.02] p-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#2a2a35] to-[#15151c] text-[12px] font-black text-[#b8ff2e] ring-1 ring-white/10">{p.initials}</div>
              <div className="min-w-0 flex-1 leading-tight">
                <div className="truncate text-[12px] font-extrabold text-white">{p.name}</div>
                <div className="truncate text-[10px] font-semibold text-white/35">{p.unit}</div>
              </div>
              <button onClick={onLogout} title="Sign out" aria-label="Sign out" className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/35 transition hover:bg-[#ff3b4e]/10 hover:text-[#ff6b7a]"><LogOut className="h-4 w-4" /></button>
            </div>
          </div>
        ) : (
          <div className="mt-4 flex flex-col items-center gap-3">
            <span className="relative flex h-2.5 w-2.5"><span className="absolute h-full w-full animate-ping rounded-full bg-[#b8ff2e] opacity-60" /><span className="h-2.5 w-2.5 rounded-full bg-[#b8ff2e]" /></span>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-[#2a2a35] to-[#15151c] text-[12px] font-black text-[#b8ff2e] ring-1 ring-white/10">{p.initials}</div>
            <button onClick={onLogout} title="Sign out" aria-label="Sign out" className="flex h-8 w-8 items-center justify-center rounded-lg text-white/35 transition hover:bg-[#ff3b4e]/10 hover:text-[#ff6b7a]"><LogOut className="h-4 w-4" /></button>
          </div>
        )}
      </div>
    </aside>
  );
}
