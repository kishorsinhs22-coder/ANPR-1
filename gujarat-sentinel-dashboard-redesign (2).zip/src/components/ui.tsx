import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "../utils/cn";

export function CountUp({ value, duration = 1.4, format }: { value: number; duration?: number; format?: (n: number) => string }) {
  const [display, setDisplay] = useState(0);
  const raf = useRef<number>(0);
  useEffect(() => {
    const start = performance.now();
    const from = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / (duration * 1000));
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (value - from) * eased);
      if (p < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [value, duration]);
  const fmt = format ?? ((n: number) => Math.round(n).toLocaleString("en-IN"));
  return <span className="tabular-nums">{fmt(display)}</span>;
}

export function LiveDot({ color = "bg-[#b8ff2e]", size = "h-2 w-2", pulse = true }: { color?: string; size?: string; pulse?: boolean }) {
  return (
    <span className="relative inline-flex shrink-0 items-center justify-center" style={{ width: 10, height: 10 }}>
      {pulse && <span className={cn("absolute inline-flex h-full w-full animate-ping rounded-full opacity-60", color)} />}
      <span className={cn("relative inline-flex rounded-full", size, color)} style={{ boxShadow: "0 0 8px currentColor" }} />
    </span>
  );
}

export function Toggle({ on, onChange, accent = "#b8ff2e" }: { on: boolean; onChange: (v: boolean) => void; accent?: string }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="relative h-6 w-11 shrink-0 rounded-full transition-colors duration-200"
      style={{ background: on ? accent : "rgba(255,255,255,.14)" }}
      aria-pressed={on}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 500, damping: 32 }}
        className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow"
        style={{ left: on ? 22 : 2 }}
      />
    </button>
  );
}

export function Progress({ value, color = "#b8ff2e", h = "h-1.5" }: { value: number; color?: string; h?: string }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-full bg-white/[.07]", h)}>
      <motion.div
        initial={{ width: 0 }}
        whileInView={{ width: `${value}%` }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        className="h-full rounded-full"
        style={{ background: color, boxShadow: `0 0 12px ${color}66` }}
      />
    </div>
  );
}

export function Card({ children, className, hover = true, delay = 0 }: { children: ReactNode; className?: string; hover?: boolean; delay?: number }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.55, delay: delay * 0.06, ease: [0.22, 1, 0.36, 1] }}
      className={cn("card relative overflow-hidden", hover ? "card-hover" : "card-static", className)}
    >
      {children}
    </motion.section>
  );
}

export function RiskDot({ risk, pulse = false }: { risk: string; pulse?: boolean }) {
  const map: Record<string, string> = {
    critical: "bg-[#ff3b4e] shadow-[0_0_10px_#ff3b4e]",
    high: "bg-[#ff8a2b] shadow-[0_0_10px_#ff8a2b]",
    medium: "bg-[#ffc93c] shadow-[0_0_10px_#ffc93c]",
    low: "bg-[#4ea8ff] shadow-[0_0_10px_#4ea8ff]",
    normal: "bg-[#b8ff2e] shadow-[0_0_10px_#b8ff2e]",
    online: "bg-[#b8ff2e] shadow-[0_0_10px_#b8ff2e]",
    degraded: "bg-[#ffc93c] shadow-[0_0_10px_#ffc93c]",
    offline: "bg-[#ff3b4e] shadow-[0_0_10px_#ff3b4e]",
  };
  return <span className={cn("inline-block h-2 w-2 rounded-full", map[risk] ?? map.normal, pulse && "blink-soft")} />;
}

export function Pill({ children, tone = "volt", className }: { children: ReactNode; tone?: "volt" | "red" | "orange" | "yellow" | "blue" | "ghost"; className?: string }) {
  const tones: Record<string, string> = {
    volt: "bg-[#b8ff2e]/10 text-[#d3ff7d] border-[#b8ff2e]/25 hover:bg-[#b8ff2e]/20",
    red: "bg-[#ff3b4e]/10 text-[#ff8a95] border-[#ff3b4e]/30 hover:bg-[#ff3b4e]/20",
    orange: "bg-[#ff8a2b]/10 text-[#ffb37a] border-[#ff8a2b]/30 hover:bg-[#ff8a2b]/20",
    yellow: "bg-[#ffc93c]/10 text-[#ffe08a] border-[#ffc93c]/30 hover:bg-[#ffc93c]/20",
    blue: "bg-[#4ea8ff]/10 text-[#8fc6ff] border-[#4ea8ff]/30 hover:bg-[#4ea8ff]/20",
    ghost: "bg-white/[.05] text-white/70 border-white/10 hover:bg-white/10",
  };
  return (
    <span className={cn("inline-flex cursor-pointer items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-bold tracking-wide transition-all", tones[tone], className)}>
      {children}
    </span>
  );
}

export function Stat({ label, value, sub, accent }: { label: string; value: ReactNode; sub?: ReactNode; accent?: string }) {
  return (
    <div className="min-w-0">
      <div className="label-caps truncate">{label}</div>
      <div className="mt-1.5 text-xl font-extrabold tracking-tight text-white tabular-nums" style={accent ? { color: accent } : undefined}>{value}</div>
      {sub && <div className="mt-0.5 text-[11px] font-medium text-white/40">{sub}</div>}
    </div>
  );
}
