import { useId, useMemo } from "react";
import { motion } from "framer-motion";

function points(data: number[], w: number, h: number, pad = 6) {
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  return data.map((v, i) => {
    const x = pad + (i / (data.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    return [x, y] as const;
  });
}

function smoothPath(pts: readonly (readonly [number, number])[]) {
  if (pts.length < 2) return "";
  let d = `M ${pts[0][0]},${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, y0] = pts[i];
    const [x1, y1] = pts[i + 1];
    const cx = (x0 + x1) / 2;
    d += ` C ${cx},${y0} ${cx},${y1} ${x1},${y1}`;
  }
  return d;
}

export function Sparkline({ data, color = "#b8ff2e", width = 150, height = 44 }: { data: number[]; color?: string; width?: number; height?: number }) {
  const pts = useMemo(() => points(data, width, height), [data, width, height]);
  const d = smoothPath(pts);
  const id = useId();
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.35} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      <motion.path d={`${d} L ${width - 6},${height} L 6,${height} Z`} fill={`url(#${id})`} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 1 }} />
      <motion.path d={d} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }} transition={{ duration: 1.4, ease: "easeOut" }} style={{ filter: `drop-shadow(0 0 6px ${color}88)` }} />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r={3} fill={color} className="blink-soft" />
    </svg>
  );
}

export function AreaChart({ data, color = "#b8ff2e", height = 150, labels }: { data: number[]; color?: string; height?: number; labels?: string[] }) {
  const w = 600, h = height;
  const pts = useMemo(() => points(data, w, h, 10), [data, h]);
  const d = smoothPath(pts);
  const id = useId();
  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full overflow-visible" style={{ height: h }}>
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.3} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line key={f} x1={0} x2={w} y1={h * f} y2={h * f} stroke="rgba(255,255,255,.06)" strokeDasharray="4 4" />
        ))}
        <motion.path d={`${d} L ${w - 10},${h} L 10,${h} Z`} fill={`url(#${id})`} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ duration: 1 }} />
        <motion.path d={d} fill="none" stroke={color} strokeWidth={2.5} strokeLinecap="round" initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }} transition={{ duration: 1.6, ease: "easeOut" }} style={{ filter: `drop-shadow(0 0 8px ${color}88)` }} />
        {pts.map(([x, y], i) =>
          i % Math.ceil(pts.length / 6) === 0 ? <circle key={i} cx={x} cy={y} r={3} fill="#0d0d12" stroke={color} strokeWidth={2} /> : null
        )}
      </svg>
      {labels && (
        <div className="mt-2 flex justify-between text-[10px] font-semibold text-white/30">
          {labels.map((l) => <span key={l}>{l}</span>)}
        </div>
      )}
    </div>
  );
}

export function BarChart({ data, height = 150, labels }: { data: number[]; height?: number; labels?: string[] }) {
  const max = Math.max(...data);
  return (
    <div>
      <div className="flex items-end gap-1.5" style={{ height }}>
        {data.map((v, i) => {
          const hot = v / max > 0.75;
          const mid = v / max > 0.5;
          const c = hot ? "#ff8a2b" : mid ? "#b8ff2e" : "#3f7d2e";
          return (
            <motion.div
              key={i}
              initial={{ height: 0 }}
              whileInView={{ height: `${(v / max) * 100}%` }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.04, ease: [0.22, 1, 0.36, 1] }}
              className="min-h-[6px] flex-1 rounded-t-[5px]"
              style={{ background: `linear-gradient(180deg, ${c}, ${c}55)`, boxShadow: hot ? "0 0 16px -4px #ff8a2b88" : undefined }}
              title={`${v}%`}
            />
          );
        })}
      </div>
      {labels && (
        <div className="mt-2 flex justify-between text-[10px] font-semibold text-white/30">
          {labels.map((l) => <span key={l}>{l}</span>)}
        </div>
      )}
    </div>
  );
}

export function Gauge({ value, label, sub, color = "#b8ff2e", size = 120 }: { value: number; label: string; sub?: string; color?: string; size?: number }) {
  const r = 44;
  const c = 2 * Math.PI * r;
  const arc = c * 0.75;
  const off = arc - (value / 100) * arc;
  return (
    <div className="flex flex-col items-center" style={{ width: size }}>
      <div className="relative" style={{ width: size, height: size * 0.78 }}>
        <svg viewBox="0 0 110 84" className="w-full">
          <path d="M 12 78 A 44 44 0 0 1 98 78" fill="none" stroke="rgba(255,255,255,.08)" strokeWidth={9} strokeLinecap="round" />
          <motion.path
            d="M 12 78 A 44 44 0 0 1 98 78"
            fill="none" stroke={color} strokeWidth={9} strokeLinecap="round"
            strokeDasharray={arc} initial={{ strokeDashoffset: arc }} whileInView={{ strokeDashoffset: off }}
            viewport={{ once: true }} transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
            style={{ filter: `drop-shadow(0 0 8px ${color}99)` }}
          />
        </svg>
        <div className="absolute inset-x-0 bottom-0 text-center">
          <div className="text-2xl font-extrabold tabular-nums leading-none">{value}<span className="text-xs text-white/40 font-bold">%</span></div>
        </div>
      </div>
      <div className="label-caps mt-1 text-center">{label}</div>
      {sub && <div className="text-[11px] text-white/40 font-semibold">{sub}</div>}
    </div>
  );
}

export function Ring({ value, size = 64, stroke = 7, color = "#b8ff2e", children }: { value: number; size?: number; stroke?: number; color?: string; children?: React.ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (value / 100) * c;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,.08)" strokeWidth={stroke} />
        <motion.circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} initial={{ strokeDashoffset: c }} whileInView={{ strokeDashoffset: off }}
          viewport={{ once: true }} transition={{ duration: 1.3, ease: [0.22, 1, 0.36, 1] }}
          style={{ filter: `drop-shadow(0 0 6px ${color}88)` }} />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">{children}</div>
    </div>
  );
}
