import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import type { Camera, TrajectoryStop } from "../data/mock";
import { cn } from "../utils/cn";

interface Props {
  cameras: Camera[];
  selected?: string | null;
  onSelect?: (c: Camera) => void;
  route?: TrajectoryStop[];
  showRoute?: boolean;
  height?: number;
  showLabels?: boolean;
}

const STATUS_COLOR: Record<string, string> = {
  online: "#b8ff2e",
  degraded: "#ffc93c",
  offline: "#ff3b4e",
};

export default function VadodaraMap({ cameras, selected, onSelect, route, showRoute = true, height = 460, showLabels = true }: Props) {
  const [hover, setHover] = useState<string | null>(null);
  const W = 1000, H = 620;

  const routePath = useMemo(() => {
    if (!route || route.length < 2) return "";
    const pts = route.map((s) => [(s.x / 100) * W, (s.y / 100) * H] as const);
    let d = `M ${pts[0][0]},${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const [x0, y0] = pts[i];
      const [x1, y1] = pts[i + 1];
      const mx = (x0 + x1) / 2;
      d += ` C ${mx},${y0} ${mx},${y1} ${x1},${y1}`;
    }
    return d;
  }, [route]);

  // ambient moving vehicles on secondary roads
  const ambient = [
    "M 60,480 C 240,460 320,380 480,360 S 760,300 940,220",
    "M 120,120 C 260,180 340,300 420,420 S 560,560 700,580",
    "M 80,300 C 300,280 520,320 720,420 S 860,520 950,540",
  ];

  return (
    <div className="relative w-full overflow-hidden rounded-[14px] bg-[#07070b]" style={{ height }}>
      {/* base grid + vignette */}
      <div className="map-grid absolute inset-0 opacity-70" />
      <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(120% 90% at 50% 10%, transparent 40%, rgba(0,0,0,.55) 100%)" }} />

      <svg viewBox={`0 0 ${W} ${H}`} className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <linearGradient id="river" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#123043" />
            <stop offset="100%" stopColor="#0d2230" />
          </linearGradient>
          <linearGradient id="routeGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#b8ff2e" stopOpacity=".55" />
            <stop offset="100%" stopColor="#b8ff2e" />
          </linearGradient>
        </defs>

        {/* river Vishwamitri */}
        <path d="M 180,-20 C 260,120 200,240 300,340 C 400,440 380,520 460,640" stroke="url(#river)" strokeWidth={26} fill="none" opacity={.9} strokeLinecap="round" />
        <path d="M 180,-20 C 260,120 200,240 300,340 C 400,440 380,520 460,640" stroke="#1d4d63" strokeWidth={1.5} fill="none" opacity={.5} strokeDasharray="6 8" />

        {/* arterial roads */}
        <g stroke="#23232c" strokeWidth={10} fill="none" strokeLinecap="round" opacity={.95}>
          <path d="M -20,180 C 220,170 420,200 700,140 S 900,120 1020,150" />
          <path d="M -20,420 C 240,410 480,470 720,430 S 920,400 1020,430" />
          <path d="M 420,-20 C 430,160 400,360 440,640" />
          <path d="M 680,-20 C 660,180 700,380 660,640" />
        </g>
        <g stroke="#2e2e38" strokeWidth={3} fill="none" strokeLinecap="round" opacity={.9}>
          <path d="M -20,180 C 220,170 420,200 700,140 S 900,120 1020,150" strokeDasharray="18 14" />
          <path d="M -20,420 C 240,410 480,470 720,430 S 920,400 1020,430" strokeDasharray="18 14" />
        </g>
        {/* minor streets */}
        <g stroke="rgba(255,255,255,.055)" strokeWidth={1.5} fill="none">
          {Array.from({ length: 9 }).map((_, i) => (
            <path key={`h${i}`} d={`M -20,${60 + i * 62} C 300,${50 + i * 62} 620,${80 + i * 62} 1020,${55 + i * 62}`} />
          ))}
          {Array.from({ length: 8 }).map((_, i) => (
            <path key={`v${i}`} d={`M ${80 + i * 120},-20 C ${70 + i * 120},220 ${100 + i * 120},400 ${85 + i * 120},640`} />
          ))}
        </g>

        {/* congestion heat blobs */}
        <g opacity={.5}>
          <ellipse cx={620} cy={300} rx={120} ry={70} fill="#ff8a2b" opacity={.14} />
          <ellipse cx={620} cy={300} rx={70} ry={40} fill="#ff8a2b" opacity={.16} />
          <ellipse cx={450} cy={470} rx={100} ry={60} fill="#ffc93c" opacity={.12} />
          <ellipse cx={760} cy={480} rx={90} ry={55} fill="#ff3b4e" opacity={.12} />
        </g>

        {/* ambient traffic */}
        {ambient.map((d, i) => (
          <g key={i}>
            <path d={d} stroke="rgba(255,255,255,.05)" strokeWidth={5} fill="none" />
            {[0.15, 0.5, 0.8].map((off, j) => (
              <circle key={j} r={3.2} fill={i === 2 ? "#4ea8ff" : "#ffffff"} opacity={.75}>
                <animateMotion dur={`${9 + i * 3 + j}s`} repeatCount="indefinite" path={d} begin={`${-(off * (9 + i * 3))}s`} />
              </circle>
            ))}
          </g>
        ))}

        {/* main route */}
        {showRoute && route && routePath && (
          <g filter="url(#glow)">
            <motion.path d={routePath} stroke="#0c1a05" strokeWidth={11} fill="none" strokeLinecap="round" opacity={.9} initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }} transition={{ duration: 2, ease: "easeOut" }} />
            <motion.path d={routePath} stroke="url(#routeGrad)" strokeWidth={4.5} fill="none" strokeLinecap="round" initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }} transition={{ duration: 2, ease: "easeOut" }} />
            <path d={routePath} stroke="#e4ff9e" strokeWidth={1.4} fill="none" strokeLinecap="round" strokeDasharray="2 12" className="route-flow" opacity={.9} />
            {/* moving suspect vehicle */}
            <g filter="url(#glow)">
              <circle r={7} fill="#b8ff2e">
                <animateMotion dur="14s" repeatCount="indefinite" path={routePath} />
              </circle>
              <circle r={12} fill="none" stroke="#b8ff2e" strokeWidth={1.5} opacity={.6}>
                <animateMotion dur="14s" repeatCount="indefinite" path={routePath} />
              </circle>
            </g>
          </g>
        )}

        {/* camera nodes */}
        {cameras.map((c) => {
          const cx = (c.x / 100) * W;
          const cy = (c.y / 100) * H;
          const col = STATUS_COLOR[c.status];
          const active = selected === c.id || hover === c.id;
          return (
            <g key={c.id} className="cursor-pointer" onClick={() => onSelect?.(c)} onMouseEnter={() => setHover(c.id)} onMouseLeave={() => setHover(null)}>
              <circle cx={cx} cy={cy} r={22} fill="transparent" />
              {c.status === "online" && (
                <circle cx={cx} cy={cy} r={10} fill="none" stroke={col} strokeWidth={1} opacity={.5}>
                  <animate attributeName="r" values="7;16" dur="2s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values=".7;0" dur="2s" repeatCount="indefinite" />
                </circle>
              )}
              <circle cx={cx} cy={cy} r={active ? 9 : 6.5} fill="#0a0a0c" stroke={col} strokeWidth={2.5} filter="url(#glow)" style={{ transition: "r .2s" }} />
              <circle cx={cx} cy={cy} r={2.6} fill={col} />
              {showLabels && (active || c.status !== "online") && (
                <g>
                  <rect x={cx + 12} y={cy - 14} width={c.id.length * 7.4 + 18} height={22} rx={6} fill="rgba(5,5,8,.92)" stroke="rgba(255,255,255,.14)" />
                  <text x={cx + 21} y={cy + 1} fill="#fff" fontSize={11} fontWeight={700} fontFamily="JetBrains Mono, monospace">{c.id}</text>
                </g>
              )}
            </g>
          );
        })}

        {/* trajectory glowing nodes */}
        {showRoute && route?.map((s, i) => {
          const cx = (s.x / 100) * W;
          const cy = (s.y / 100) * H;
          const isLast = i === route.length - 1;
          return (
            <g key={i} filter="url(#glow)">
              <circle cx={cx} cy={cy} r={isLast ? 8 : 5.5} fill={isLast ? "#b8ff2e" : "#0a0a0c"} stroke="#b8ff2e" strokeWidth={isLast ? 0 : 3} />
              {isLast && <circle cx={cx} cy={cy} r={4} fill="#0a0a0c" />}
              <text x={cx} y={cy - 16} textAnchor="middle" fill="rgba(255,255,255,.75)" fontSize={11} fontWeight={700}>{s.time}</text>
            </g>
          );
        })}

        {/* area labels */}
        {showLabels && (
          <g fontFamily="Manrope, sans-serif" fontWeight={800} fontSize={13} letterSpacing={2} fill="rgba(255,255,255,.22)">
            <text x={380} y={130}>FATEHGUNJ</text>
            <text x={600} y={200}>RACE COURSE</text>
            <text x={300} y={330}>ALKAPURI</text>
            <text x={560} y={360}>SAYAJIGUNJ</text>
            <text x={180} y={470}>AKOTA</text>
            <text x={700} y={560}>MANJALPUR</text>
            <text x={120} y={580}>GOTRI</text>
          </g>
        )}
      </svg>

      {/* hover tooltip */}
      {hover && (() => {
        const c = cameras.find((x) => x.id === hover);
        if (!c) return null;
        return (
          <div
            className="pointer-events-none absolute z-20 w-52 rounded-xl border border-white/10 bg-[#0b0b10]/95 p-3 shadow-2xl backdrop-blur-xl"
            style={{ left: `min(max(${c.x}%, 8rem), calc(100% - 14rem))`, top: `min(max(${c.y}%, 6rem), calc(100% - 9rem))`, transform: "translate(14px,-50%)" }}
          >
            <div className="font-mono text-[11px] font-bold text-white">{c.id}</div>
            <div className="text-[11px] font-semibold text-white/50">{c.name}</div>
            <div className="mt-2 flex items-center gap-2 text-[11px] font-bold">
              <span className={cn("h-1.5 w-1.5 rounded-full", c.status === "online" ? "bg-[#b8ff2e]" : c.status === "degraded" ? "bg-[#ffc93c]" : "bg-[#ff3b4e]")} />
              <span className="uppercase tracking-wider text-white/80">{c.status}</span>
              <span className="ml-auto text-white/40">{c.fps} FPS</span>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
